<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-09 11:02:27 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 11:02:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 11:02:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 11:08:01 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 11:08:01 --> Severity: Notice --> Undefined variable: fem C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 192
ERROR - 2020-01-09 11:08:01 --> Severity: Notice --> Undefined variable: male C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 193
ERROR - 2020-01-09 11:08:01 --> Severity: Notice --> Undefined variable: ch C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 194
ERROR - 2020-01-09 11:08:01 --> Severity: Notice --> Undefined variable: tot C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 195
ERROR - 2020-01-09 11:10:28 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 11:30:09 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 11:30:09 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 11:49:05 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 11:59:19 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 11:59:19 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 11:59:46 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 11:59:47 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 12:05:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 12:05:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 12:06:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 12:07:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 12:08:11 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 12:08:11 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 12:08:11 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 12:09:44 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 12:09:47 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 12:10:38 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 12:12:01 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 12:12:16 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 12:17:40 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 12:18:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 12:18:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 12:18:21 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 12:18:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 12:18:58 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 12:21:20 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 12:33:06 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 12:36:50 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 12:37:10 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 12:37:52 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 12:38:16 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 12:38:16 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 12:38:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 12:38:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 12:38:51 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 12:41:02 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 12:41:31 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 12:43:53 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 12:44:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 12:44:55 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 12:45:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 12:46:01 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 12:46:01 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 12:46:01 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 12:46:19 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 12:50:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 12:51:24 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 12:53:06 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 12:53:06 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 12:53:06 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 12:54:24 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 12:59:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 12:59:36 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 13:00:09 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 13:00:53 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 13:01:14 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 13:01:54 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 13:02:47 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 13:03:56 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 13:05:37 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 13:05:50 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 13:05:50 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 13:06:12 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 13:06:54 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 13:07:10 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 13:07:28 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 13:07:40 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 13:09:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 13:09:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 13:09:40 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 13:10:00 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 13:10:10 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 13:11:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 13:13:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 13:13:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 13:13:34 --> 404 Page Not Found: /index
ERROR - 2020-01-09 13:13:40 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 13:13:40 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 13:13:40 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 13:13:40 --> 404 Page Not Found: /index
ERROR - 2020-01-09 13:16:25 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 13:16:26 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 13:16:26 --> 404 Page Not Found: /index
ERROR - 2020-01-09 13:16:29 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 14:16:13 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 14:18:27 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 14:21:16 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 14:21:21 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 14:21:21 --> 404 Page Not Found: /index
ERROR - 2020-01-09 14:21:23 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 14:21:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 14:21:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 14:22:02 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 14:22:29 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 14:22:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 14:24:14 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 14:25:48 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 14:25:55 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 14:25:55 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 14:25:55 --> 404 Page Not Found: /index
ERROR - 2020-01-09 14:26:00 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 14:26:00 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 14:26:01 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 14:26:01 --> 404 Page Not Found: /index
ERROR - 2020-01-09 14:26:38 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 14:26:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 14:28:23 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 14:28:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 14:30:12 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 14:30:12 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ')' C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 63
ERROR - 2020-01-09 14:30:26 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 14:30:26 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 62
ERROR - 2020-01-09 14:30:44 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 14:30:50 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 14:33:49 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 14:33:49 --> Severity: Notice --> Undefined index: monthfil C:\danxampp\htdocs\demo\application\modules\admindashboard\controllers\Admindashboard.php 120
ERROR - 2020-01-09 14:34:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 14:35:46 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 14:36:12 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 14:45:06 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 14:47:57 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 14:51:32 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 14:51:51 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 14:52:06 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 14:53:11 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 14:53:44 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 14:54:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 14:54:09 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 14:54:20 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 14:54:32 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 14:55:06 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 14:57:38 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 14:58:02 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 14:59:54 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:00:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:00:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:00:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:02:05 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:02:12 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:02:29 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:02:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:02:54 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:02:58 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:03:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:03:51 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:04:01 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:07:18 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:07:28 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:07:42 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:07:51 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:08:11 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:08:12 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:08:20 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:08:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:08:48 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:09:10 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:09:20 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:09:42 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:09:54 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:10:01 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:10:45 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:10:56 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:11:07 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:11:18 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:11:31 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:11:37 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:12:10 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:12:16 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:12:22 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:12:28 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:12:40 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:12:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:12:46 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:13:04 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:13:27 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:14:18 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:14:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:19:24 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:23:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:23:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:23:30 --> 404 Page Not Found: /index
ERROR - 2020-01-09 15:23:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:23:36 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:23:36 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:23:36 --> 404 Page Not Found: /index
ERROR - 2020-01-09 15:29:51 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:29:51 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:29:51 --> 404 Page Not Found: /index
ERROR - 2020-01-09 15:31:05 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:31:05 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:31:05 --> 404 Page Not Found: /index
ERROR - 2020-01-09 15:31:11 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:31:11 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:31:11 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:31:11 --> 404 Page Not Found: /index
ERROR - 2020-01-09 15:31:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:31:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:31:30 --> 404 Page Not Found: /index
ERROR - 2020-01-09 15:31:56 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:31:56 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:31:56 --> 404 Page Not Found: /index
ERROR - 2020-01-09 15:32:00 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:32:00 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:32:00 --> 404 Page Not Found: /index
ERROR - 2020-01-09 15:32:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:32:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:32:35 --> 404 Page Not Found: /index
ERROR - 2020-01-09 15:33:07 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:33:07 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:33:07 --> 404 Page Not Found: /index
ERROR - 2020-01-09 15:33:11 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:33:11 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:33:11 --> 404 Page Not Found: /index
ERROR - 2020-01-09 15:34:26 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:34:26 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:34:26 --> 404 Page Not Found: /index
ERROR - 2020-01-09 15:34:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:34:33 --> Query error: Duplicate entry '931743255-2019-04-01' for key 'PRIMARY' - Invalid query: INSERT INTO `import_beneficiaries` (`beneficiary_id`, `sex`, `region`, `entry_date_to_since`, `target_group`, `value_chain`, `entry_point_income`, `endline_income`, `type_of_income`, `disabled`, `Employed`, `consortium`, `status`, `postdate`) VALUES ('931743255', 'Female', 'Addis Ababa', '2019-04-01', 'Returnee', '3', '', '', 'Informal', 'FALSE', 'FALSE', 'Lot_1_VIS_2nd_batch', 1, '2020-01-09')
ERROR - 2020-01-09 15:34:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:34:33 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 89
ERROR - 2020-01-09 15:34:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:34:33 --> 404 Page Not Found: /index
ERROR - 2020-01-09 15:35:20 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:35:20 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:35:20 --> 404 Page Not Found: /index
ERROR - 2020-01-09 15:35:25 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:35:25 --> Query error: Duplicate entry '931743255-2019-04-01' for key 'PRIMARY' - Invalid query: INSERT INTO `import_beneficiaries` (`beneficiary_id`, `sex`, `region`, `entry_date_to_since`, `target_group`, `value_chain`, `entry_point_income`, `endline_income`, `type_of_income`, `disabled`, `Employed`, `consortium`, `status`, `postdate`) VALUES ('931743255', 'Female', 'Addis Ababa', '2019-04-01', 'Returnee', '3', '', '', 'Informal', 'FALSE', 'FALSE', 'Lot_1_VIS_2nd_batch', 1, '2020-01-09')
ERROR - 2020-01-09 15:35:25 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:35:25 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:35:25 --> 404 Page Not Found: /index
ERROR - 2020-01-09 15:35:31 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:35:31 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:35:31 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:35:31 --> 404 Page Not Found: /index
ERROR - 2020-01-09 15:35:54 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:35:54 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:35:54 --> 404 Page Not Found: /index
ERROR - 2020-01-09 15:35:58 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:35:58 --> Query error: Duplicate entry '931743255-2019-04-01' for key 'PRIMARY' - Invalid query: INSERT INTO `import_beneficiaries` (`beneficiary_id`, `sex`, `region`, `entry_date_to_since`, `target_group`, `value_chain`, `entry_point_income`, `endline_income`, `type_of_income`, `disabled`, `Employed`, `consortium`, `status`, `postdate`) VALUES ('931743255', 'Female', 'Addis Ababa', '2019-04-01', 'Returnee', '3', '', '', 'Informal', 'FALSE', 'FALSE', 'Lot_1_VIS_2nd_batch', 1, '2020-01-09')
ERROR - 2020-01-09 15:35:58 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:35:58 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 51
ERROR - 2020-01-09 15:35:58 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:35:58 --> 404 Page Not Found: /index
ERROR - 2020-01-09 15:36:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:36:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:36:17 --> 404 Page Not Found: /index
ERROR - 2020-01-09 15:36:21 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:36:21 --> Query error: Duplicate entry '931743255-2019-04-01' for key 'PRIMARY' - Invalid query: INSERT INTO `import_beneficiaries` (`beneficiary_id`, `sex`, `region`, `entry_date_to_since`, `target_group`, `value_chain`, `entry_point_income`, `endline_income`, `type_of_income`, `disabled`, `Employed`, `consortium`, `status`, `postdate`) VALUES ('931743255', 'Female', 'Addis Ababa', '2019-04-01', 'Returnee', '3', '', '', 'Informal', 'FALSE', 'FALSE', 'Lot_1_VIS_2nd_batch', 1, '2020-01-09')
ERROR - 2020-01-09 15:36:21 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:36:21 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 51
ERROR - 2020-01-09 15:36:22 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:36:22 --> 404 Page Not Found: /index
ERROR - 2020-01-09 15:37:06 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:37:06 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:37:06 --> 404 Page Not Found: /index
ERROR - 2020-01-09 15:37:11 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:37:19 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:37:27 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:37:31 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:37:31 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:37:31 --> 404 Page Not Found: /index
ERROR - 2020-01-09 15:37:36 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:37:36 --> Query error: Duplicate entry '931743255-2019-04-01' for key 'PRIMARY' - Invalid query: INSERT INTO `import_beneficiaries` (`beneficiary_id`, `sex`, `region`, `entry_date_to_since`, `target_group`, `value_chain`, `entry_point_income`, `endline_income`, `type_of_income`, `disabled`, `Employed`, `consortium`, `status`, `postdate`) VALUES ('931743255', 'Female', 'Addis Ababa', '2019-04-01', 'Returnee', '3', '', '', 'Informal', 'FALSE', 'FALSE', 'Lot_1_VIS_2nd_batch', 1, '2020-01-09')
ERROR - 2020-01-09 15:37:36 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:37:36 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 51
ERROR - 2020-01-09 15:37:36 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:37:36 --> 404 Page Not Found: /index
ERROR - 2020-01-09 15:38:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:38:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:38:17 --> 404 Page Not Found: /index
ERROR - 2020-01-09 15:38:21 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:38:21 --> Query error: Duplicate entry '931743255-2019-04-01' for key 'PRIMARY' - Invalid query: INSERT INTO `import_beneficiaries` (`beneficiary_id`, `sex`, `region`, `entry_date_to_since`, `target_group`, `value_chain`, `entry_point_income`, `endline_income`, `type_of_income`, `disabled`, `Employed`, `consortium`, `status`, `postdate`) VALUES ('931743255', 'Female', 'Addis Ababa', '2019-04-01', 'Returnee', '3', '', '', 'Informal', 'FALSE', 'FALSE', 'Lot_1_VIS_2nd_batch', 1, '2020-01-09')
ERROR - 2020-01-09 15:38:21 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:38:21 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 94
ERROR - 2020-01-09 15:38:21 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:38:21 --> 404 Page Not Found: /index
ERROR - 2020-01-09 15:38:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:38:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:38:39 --> 404 Page Not Found: /index
ERROR - 2020-01-09 15:41:52 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:41:53 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:41:53 --> 404 Page Not Found: /index
ERROR - 2020-01-09 15:41:58 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:41:58 --> Query error: Duplicate entry '931743255-2019-04-01' for key 'PRIMARY' - Invalid query: INSERT INTO `import_beneficiaries` (`beneficiary_id`, `sex`, `region`, `entry_date_to_since`, `target_group`, `value_chain`, `entry_point_income`, `endline_income`, `type_of_income`, `disabled`, `Employed`, `consortium`, `status`, `postdate`) VALUES ('931743255', 'Female', 'Addis Ababa', '2019-04-01', 'Returnee', '3', '', '', 'Informal', 'FALSE', 'FALSE', 'Lot_1_VIS_2nd_batch', 1, '2020-01-09')
ERROR - 2020-01-09 15:41:58 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:41:58 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 56
ERROR - 2020-01-09 15:41:58 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:41:58 --> 404 Page Not Found: /index
ERROR - 2020-01-09 15:42:03 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:42:04 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:42:04 --> 404 Page Not Found: /index
ERROR - 2020-01-09 15:42:07 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:42:08 --> Query error: Duplicate entry '931743255-2019-04-01' for key 'PRIMARY' - Invalid query: INSERT INTO `import_beneficiaries` (`beneficiary_id`, `sex`, `region`, `entry_date_to_since`, `target_group`, `value_chain`, `entry_point_income`, `endline_income`, `type_of_income`, `disabled`, `Employed`, `consortium`, `status`, `postdate`) VALUES ('931743255', 'Female', 'Addis Ababa', '2019-04-01', 'Returnee', '3', '', '', 'Informal', 'FALSE', 'FALSE', 'Lot_1_VIS_2nd_batch', 1, '2020-01-09')
ERROR - 2020-01-09 15:42:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:42:08 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 56
ERROR - 2020-01-09 15:42:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:42:08 --> 404 Page Not Found: /index
ERROR - 2020-01-09 15:42:21 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:42:21 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:42:21 --> 404 Page Not Found: /index
ERROR - 2020-01-09 15:42:25 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:42:25 --> Query error: Duplicate entry '931743255-2019-04-01' for key 'PRIMARY' - Invalid query: INSERT INTO `import_beneficiaries` (`beneficiary_id`, `sex`, `region`, `entry_date_to_since`, `target_group`, `value_chain`, `entry_point_income`, `endline_income`, `type_of_income`, `disabled`, `Employed`, `consortium`, `status`, `postdate`) VALUES ('931743255', 'Female', 'Addis Ababa', '2019-04-01', 'Returnee', '3', '', '', 'Informal', 'FALSE', 'FALSE', 'Lot_1_VIS_2nd_batch', 1, '2020-01-09')
ERROR - 2020-01-09 15:42:25 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:42:25 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 58
ERROR - 2020-01-09 15:42:26 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:42:26 --> 404 Page Not Found: /index
ERROR - 2020-01-09 15:42:49 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:42:49 --> Query error: Duplicate entry '100000' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100000', 'General Wingate College11', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:42:49 --> Query error: Duplicate entry '100001' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100001', 'Lideta Manufacturing College', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:42:49 --> Query error: Duplicate entry '100002' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100002', 'Misrak Polytechnic College', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:42:49 --> Query error: Duplicate entry '100005' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100005', 'Yeka Industrial College', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:42:50 --> Query error: Duplicate entry '100008' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100008', 'Entoto PTC', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:42:50 --> Query error: Duplicate entry '100009' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100009', 'Addis Ketema Manufacturing College', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:42:50 --> Query error: Duplicate entry '100010' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100010', 'General Wingate College', 'Addis Ababa', '', 1, '2020-01-09')
ERROR - 2020-01-09 15:42:50 --> Query error: Duplicate entry '100011' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100011', 'General Wingate College4545', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:42:50 --> Query error: Duplicate entry '100012' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100012', 'Entoto PTC1', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:42:50 --> Query error: Duplicate entry '100014' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100014', 'Entoto PTC222', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:42:50 --> Query error: Duplicate entry '100017' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100017', 'Entoto_PTC', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:42:50 --> Query error: Duplicate entry '100018' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100018', 'Entoto_PTC2', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:42:50 --> Query error: Duplicate entry '100019' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100019', 'Entoto PTC22222', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:42:50 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:42:50 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 58
ERROR - 2020-01-09 15:42:50 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:42:50 --> 404 Page Not Found: /index
ERROR - 2020-01-09 15:43:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:43:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:43:59 --> 404 Page Not Found: /index
ERROR - 2020-01-09 15:44:04 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:44:04 --> Query error: Duplicate entry '100000' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100000', 'General Wingate College11', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:44:04 --> Query error: Duplicate entry '100001' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100001', 'Lideta Manufacturing College', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:44:04 --> Query error: Duplicate entry '100002' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100002', 'Misrak Polytechnic College', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:44:04 --> Query error: Duplicate entry '100005' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100005', 'Yeka Industrial College', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:44:04 --> Query error: Duplicate entry '100008' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100008', 'Entoto PTC', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:44:04 --> Query error: Duplicate entry '100009' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100009', 'Addis Ketema Manufacturing College', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:44:04 --> Query error: Duplicate entry '100010' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100010', 'General Wingate College', 'Addis Ababa', '', 1, '2020-01-09')
ERROR - 2020-01-09 15:44:04 --> Query error: Duplicate entry '100011' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100011', 'General Wingate College4545', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:44:04 --> Query error: Duplicate entry '100012' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100012', 'Entoto PTC1', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:44:04 --> Query error: Duplicate entry '100014' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100014', 'Entoto PTC222', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:44:04 --> Query error: Duplicate entry '100017' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100017', 'Entoto_PTC', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:44:04 --> Query error: Duplicate entry '100018' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100018', 'Entoto_PTC2', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:44:04 --> Query error: Duplicate entry '100019' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100019', 'Entoto PTC22222', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:44:04 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:44:04 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 96
ERROR - 2020-01-09 15:44:04 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:44:04 --> 404 Page Not Found: /index
ERROR - 2020-01-09 15:44:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:44:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:44:34 --> 404 Page Not Found: /index
ERROR - 2020-01-09 15:44:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:44:39 --> Query error: Duplicate entry '100000' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100000', 'General Wingate College11', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:44:39 --> Query error: Duplicate entry '100001' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100001', 'Lideta Manufacturing College', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:44:39 --> Query error: Duplicate entry '100002' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100002', 'Misrak Polytechnic College', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:44:39 --> Query error: Duplicate entry '100005' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100005', 'Yeka Industrial College', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:44:39 --> Query error: Duplicate entry '100008' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100008', 'Entoto PTC', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:44:39 --> Query error: Duplicate entry '100009' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100009', 'Addis Ketema Manufacturing College', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:44:39 --> Query error: Duplicate entry '100010' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100010', 'General Wingate College', 'Addis Ababa', '', 1, '2020-01-09')
ERROR - 2020-01-09 15:44:39 --> Query error: Duplicate entry '100011' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100011', 'General Wingate College4545', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:44:39 --> Query error: Duplicate entry '100012' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100012', 'Entoto PTC1', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:44:39 --> Query error: Duplicate entry '100014' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100014', 'Entoto PTC222', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:44:39 --> Query error: Duplicate entry '100017' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100017', 'Entoto_PTC', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:44:39 --> Query error: Duplicate entry '100018' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100018', 'Entoto_PTC2', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:44:39 --> Query error: Duplicate entry '100019' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100019', 'Entoto PTC22222', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:44:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:44:39 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 96
ERROR - 2020-01-09 15:44:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:44:39 --> 404 Page Not Found: /index
ERROR - 2020-01-09 15:44:52 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:44:53 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:44:53 --> 404 Page Not Found: /index
ERROR - 2020-01-09 15:45:04 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:45:04 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:45:04 --> 404 Page Not Found: /index
ERROR - 2020-01-09 15:45:27 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:45:27 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:45:27 --> 404 Page Not Found: /index
ERROR - 2020-01-09 15:45:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:45:35 --> Query error: Duplicate entry '100000' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100000', 'General Wingate College11', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:45:35 --> Query error: Duplicate entry '100001' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100001', 'Lideta Manufacturing College', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:45:35 --> Query error: Duplicate entry '100002' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100002', 'Misrak Polytechnic College', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:45:35 --> Query error: Duplicate entry '100005' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100005', 'Yeka Industrial College', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:45:35 --> Query error: Duplicate entry '100008' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100008', 'Entoto PTC', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:45:35 --> Query error: Duplicate entry '100009' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100009', 'Addis Ketema Manufacturing College', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:45:35 --> Query error: Duplicate entry '100010' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100010', 'General Wingate College', 'Addis Ababa', '', 1, '2020-01-09')
ERROR - 2020-01-09 15:45:35 --> Query error: Duplicate entry '100011' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100011', 'General Wingate College4545', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:45:35 --> Query error: Duplicate entry '100012' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100012', 'Entoto PTC1', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:45:35 --> Query error: Duplicate entry '100014' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100014', 'Entoto PTC222', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:45:35 --> Query error: Duplicate entry '100017' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100017', 'Entoto_PTC', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:45:35 --> Query error: Duplicate entry '100018' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100018', 'Entoto_PTC2', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:45:35 --> Query error: Duplicate entry '100019' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100019', 'Entoto PTC22222', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:45:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:45:35 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 101
ERROR - 2020-01-09 15:45:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:45:35 --> 404 Page Not Found: /index
ERROR - 2020-01-09 15:47:16 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:47:16 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:47:16 --> 404 Page Not Found: /index
ERROR - 2020-01-09 15:47:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:47:34 --> Query error: Duplicate entry '100000' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100000', 'General Wingate College11', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:47:34 --> Query error: Duplicate entry '100001' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100001', 'Lideta Manufacturing College', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:47:34 --> Query error: Duplicate entry '100002' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100002', 'Misrak Polytechnic College', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:47:34 --> Query error: Duplicate entry '100005' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100005', 'Yeka Industrial College', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:47:34 --> Query error: Duplicate entry '100008' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100008', 'Entoto PTC', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:47:34 --> Query error: Duplicate entry '100009' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100009', 'Addis Ketema Manufacturing College', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:47:34 --> Query error: Duplicate entry '100010' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100010', 'General Wingate College', 'Addis Ababa', '', 1, '2020-01-09')
ERROR - 2020-01-09 15:47:34 --> Query error: Duplicate entry '100011' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100011', 'General Wingate College4545', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:47:34 --> Query error: Duplicate entry '100012' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100012', 'Entoto PTC1', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:47:34 --> Query error: Duplicate entry '100014' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100014', 'Entoto PTC222', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:47:34 --> Query error: Duplicate entry '100017' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100017', 'Entoto_PTC', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:47:34 --> Query error: Duplicate entry '100018' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100018', 'Entoto_PTC2', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:47:34 --> Query error: Duplicate entry '100019' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100019', 'Entoto PTC22222', 'Addis Ababa', 'Public', 1, '2020-01-09')
ERROR - 2020-01-09 15:47:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:47:34 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 123
ERROR - 2020-01-09 15:47:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:47:34 --> 404 Page Not Found: /index
ERROR - 2020-01-09 15:47:47 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:47:47 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-09 15:47:48 --> 404 Page Not Found: /index
