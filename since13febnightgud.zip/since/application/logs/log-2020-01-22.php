<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-22 11:10:04 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:10:05 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:10:11 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:10:11 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:10:21 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:10:21 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:11:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:11:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:11:23 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:11:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:11:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:11:34 --> 404 Page Not Found: /index
ERROR - 2020-01-22 11:11:36 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:20:22 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:21:21 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:25:29 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:25:36 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:25:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:26:03 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:26:07 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:26:37 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:26:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:28:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:28:12 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:32:36 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:32:51 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:33:45 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:34:11 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:34:20 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:34:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:34:36 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:40:21 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:40:24 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:40:54 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:40:56 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:41:03 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:41:06 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:41:25 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:41:27 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:41:42 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:46:42 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:46:46 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:47:52 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:48:38 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:48:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:48:48 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:48:49 --> 404 Page Not Found: /index
ERROR - 2020-01-22 11:50:27 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:50:31 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:50:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:50:42 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:50:42 --> 404 Page Not Found: /index
ERROR - 2020-01-22 11:51:15 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:51:19 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:51:25 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:51:27 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:51:28 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:53:32 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:53:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:53:37 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:54:01 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:54:06 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:54:09 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:54:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:54:38 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:54:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:54:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:54:45 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:56:03 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:56:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:56:12 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:58:12 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:58:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:58:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:58:31 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:58:31 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:58:31 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:58:31 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:58:31 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:58:31 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:58:32 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:58:32 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:58:32 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:58:32 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:58:32 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:58:32 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:58:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:58:58 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:59:55 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 11:59:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:00:15 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:00:16 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:00:20 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:00:24 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:00:44 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:00:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:01:04 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:01:06 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:01:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:01:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:01:09 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:01:21 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:01:44 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:01:48 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:01:50 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:02:10 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:02:10 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:02:10 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:02:11 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:02:25 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:02:27 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:02:29 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:03:26 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:03:28 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:03:31 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:03:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:03:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:03:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:04:11 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:04:14 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:04:15 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:08:40 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:08:42 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:09:50 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:09:53 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:27:32 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:27:37 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:27:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:27:51 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:27:55 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:28:25 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:28:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:29:26 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:29:32 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:30:16 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:30:18 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:30:50 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:30:52 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:31:10 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:31:13 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:31:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:31:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:31:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:31:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:31:55 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:31:57 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:31:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:31:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:32:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:32:19 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:32:31 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:32:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:32:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:33:38 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:33:40 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:33:58 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:34:09 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:34:12 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:34:16 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:34:18 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:34:19 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:34:38 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:34:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:34:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:35:06 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:35:11 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:35:15 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:35:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:35:22 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:35:26 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:35:26 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:36:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:37:03 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:37:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:37:13 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:37:13 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:37:28 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:37:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:37:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:37:55 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:37:57 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:38:00 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:38:00 --> Severity: Notice --> Undefined variable: response C:\danxampp\htdocs\since\application\modules\usermaster\controllers\Usermaster.php 127
ERROR - 2020-01-22 12:38:18 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:38:20 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:38:22 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:38:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:38:40 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:38:44 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:41:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:41:45 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:41:52 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:42:00 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:42:06 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:42:09 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:42:16 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:42:31 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:42:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:42:37 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:42:37 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:42:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:42:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:42:47 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:42:47 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:44:11 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:44:13 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:44:18 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:44:18 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:44:18 --> 404 Page Not Found: /index
ERROR - 2020-01-22 12:44:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:44:31 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:44:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:47:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:47:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:47:59 --> 404 Page Not Found: /index
ERROR - 2020-01-22 12:49:57 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:49:58 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 12:49:58 --> 404 Page Not Found: /index
ERROR - 2020-01-22 13:09:00 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 13:09:01 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 13:09:01 --> 404 Page Not Found: /index
ERROR - 2020-01-22 13:09:09 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 13:09:22 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 13:10:25 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 13:11:01 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 13:13:26 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 13:13:28 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 13:13:28 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 13:13:28 --> 404 Page Not Found: /index
ERROR - 2020-01-22 13:13:36 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 13:14:38 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 13:17:03 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 13:18:09 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 13:18:09 --> Severity: Notice --> Undefined variable: objWorksheet C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 763
ERROR - 2020-01-22 13:18:09 --> Severity: error --> Exception: Call to a member function getHighestRow() on null C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 763
ERROR - 2020-01-22 13:18:57 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 13:19:32 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 13:20:03 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 13:21:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 13:25:13 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 13:25:49 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 13:26:27 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 13:26:44 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 13:26:45 --> Severity: error --> Exception: Your requested sheet index: Beneficiary_Trainings is out of bounds. The actual number of sheets is 9. C:\danxampp\htdocs\since\application\third_party\PHPExcel.php 584
ERROR - 2020-01-22 14:23:15 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 14:24:00 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 14:24:15 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 14:43:11 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 14:43:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 14:43:36 --> Severity: error --> Exception: Call to undefined method PHPExcel_Worksheet::getData() C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 796
ERROR - 2020-01-22 14:43:57 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 14:43:57 --> Severity: error --> Exception: Your requested sheet index: Beneficiary_Trainings is out of bounds. The actual number of sheets is 9. C:\danxampp\htdocs\since\application\third_party\PHPExcel.php 584
ERROR - 2020-01-22 14:44:18 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 14:44:18 --> Severity: error --> Exception: Call to undefined method PHPExcel_Worksheet::getData() C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 796
ERROR - 2020-01-22 14:48:18 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 14:48:19 --> Severity: error --> Exception: Call to undefined method PHPExcel_Worksheet::getSheet() C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 770
ERROR - 2020-01-22 14:48:40 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 14:48:41 --> Severity: error --> Exception: Call to undefined method PHPExcel_Worksheet::getData() C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 801
ERROR - 2020-01-22 14:48:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php:773) C:\danxampp\htdocs\since\system\core\Common.php 570
ERROR - 2020-01-22 14:49:03 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 14:49:03 --> Severity: error --> Exception: syntax error, unexpected '$cell_collection' (T_VARIABLE) C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 802
ERROR - 2020-01-22 14:49:11 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 14:49:12 --> Severity: error --> Exception: Call to undefined method PHPExcel_Worksheet::getData() C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 803
ERROR - 2020-01-22 14:49:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php:775) C:\danxampp\htdocs\since\system\core\Common.php 570
ERROR - 2020-01-22 14:50:29 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 14:50:30 --> Severity: error --> Exception: Call to undefined method PHPExcel_Worksheet::getData() C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 803
ERROR - 2020-01-22 14:50:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php:775) C:\danxampp\htdocs\since\system\core\Common.php 570
ERROR - 2020-01-22 14:53:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 14:53:35 --> Severity: error --> Exception: Call to undefined method PHPExcel_Worksheet::getData() C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 803
ERROR - 2020-01-22 14:53:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php:775) C:\danxampp\htdocs\since\system\core\Common.php 570
ERROR - 2020-01-22 14:54:03 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-22 14:54:04 --> Severity: error --> Exception: Call to undefined method PHPExcel_Worksheet::getData() C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 803
ERROR - 2020-01-22 14:54:57 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
