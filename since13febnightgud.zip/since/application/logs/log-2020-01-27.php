<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-27 12:05:26 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 12:24:07 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 12:24:07 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 12:24:13 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 12:24:15 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 12:27:06 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 12:27:09 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 239
ERROR - 2020-01-27 12:27:12 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 344
ERROR - 2020-01-27 12:27:13 --> Query error: Duplicate entry '0-0' for key 'PRIMARY' - Invalid query: INSERT INTO `xls_import_job_placement` (`beneficiary_id`, `placement_type`, `sme_or_cpmpany_id`, `wage`, `consortium`, `EmploymentDate`, `End_Date`, `status`, `postdate`, `file_name`) VALUES ('0', 'Employment', '', '0', '', '1970-01-01', '1970-01-01', 1, '2020-01-27', 'Lot1_Jan202020_055745PM.xlsx')
ERROR - 2020-01-27 12:27:13 --> Query error: Duplicate entry '0-0' for key 'PRIMARY' - Invalid query: INSERT INTO `xls_import_job_placement` (`beneficiary_id`, `placement_type`, `sme_or_cpmpany_id`, `wage`, `consortium`, `EmploymentDate`, `End_Date`, `status`, `postdate`, `file_name`) VALUES ('0', '', '', '0', '', '1970-01-01', '1970-01-01', 1, '2020-01-27', 'Lot1_Jan202020_055745PM.xlsx')
ERROR - 2020-01-27 12:27:13 --> Query error: Duplicate entry '0-0' for key 'PRIMARY' - Invalid query: INSERT INTO `xls_import_job_placement` (`beneficiary_id`, `placement_type`, `sme_or_cpmpany_id`, `wage`, `consortium`, `EmploymentDate`, `End_Date`, `status`, `postdate`, `file_name`) VALUES ('0', '', '', '0', '', '2019-12-01', '2019-09-29', 1, '2020-01-27', 'Lot1_Jan202020_055745PM.xlsx')
ERROR - 2020-01-27 12:27:13 --> Query error: Duplicate entry '0-0' for key 'PRIMARY' - Invalid query: INSERT INTO `xls_import_job_placement` (`beneficiary_id`, `placement_type`, `sme_or_cpmpany_id`, `wage`, `consortium`, `EmploymentDate`, `End_Date`, `status`, `postdate`, `file_name`) VALUES ('0', 'Employment', '', '0', '', '1970-01-01', '1970-01-01', 1, '2020-01-27', 'Lot1_Jan202020_055745PM.xlsx')
ERROR - 2020-01-27 12:27:13 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 539
ERROR - 2020-01-27 12:27:14 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 636
ERROR - 2020-01-27 12:27:14 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 730
ERROR - 2020-01-27 12:27:14 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 825
ERROR - 2020-01-27 12:27:14 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 921
ERROR - 2020-01-27 12:27:14 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 1022
ERROR - 2020-01-27 12:27:14 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 12:33:54 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 12:38:47 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 12:39:52 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 12:43:13 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 12:43:13 --> 404 Page Not Found: /index
ERROR - 2020-01-27 12:43:15 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 12:43:15 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 12:43:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 12:44:01 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 12:49:25 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 12:49:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 12:49:44 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 256
ERROR - 2020-01-27 12:49:46 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 361
ERROR - 2020-01-27 12:49:47 --> Query error: Duplicate entry '0-0' for key 'PRIMARY' - Invalid query: INSERT INTO `xls_import_job_placement` (`beneficiary_id`, `placement_type`, `sme_or_cpmpany_id`, `wage`, `consortium`, `EmploymentDate`, `End_Date`, `status`, `postdate`, `file_name`) VALUES ('0', 'Employment', '', '0', '', '1970-01-01', '1970-01-01', 1, '2020-01-27', 'Lot1_Jan202020_055745PM.xlsx')
ERROR - 2020-01-27 12:49:47 --> Query error: Duplicate entry '0-0' for key 'PRIMARY' - Invalid query: INSERT INTO `xls_import_job_placement` (`beneficiary_id`, `placement_type`, `sme_or_cpmpany_id`, `wage`, `consortium`, `EmploymentDate`, `End_Date`, `status`, `postdate`, `file_name`) VALUES ('0', '', '', '0', '', '1970-01-01', '1970-01-01', 1, '2020-01-27', 'Lot1_Jan202020_055745PM.xlsx')
ERROR - 2020-01-27 12:49:47 --> Query error: Duplicate entry '0-0' for key 'PRIMARY' - Invalid query: INSERT INTO `xls_import_job_placement` (`beneficiary_id`, `placement_type`, `sme_or_cpmpany_id`, `wage`, `consortium`, `EmploymentDate`, `End_Date`, `status`, `postdate`, `file_name`) VALUES ('0', '', '', '0', '', '2019-12-01', '2019-09-29', 1, '2020-01-27', 'Lot1_Jan202020_055745PM.xlsx')
ERROR - 2020-01-27 12:49:47 --> Query error: Duplicate entry '0-0' for key 'PRIMARY' - Invalid query: INSERT INTO `xls_import_job_placement` (`beneficiary_id`, `placement_type`, `sme_or_cpmpany_id`, `wage`, `consortium`, `EmploymentDate`, `End_Date`, `status`, `postdate`, `file_name`) VALUES ('0', 'Employment', '', '0', '', '1970-01-01', '1970-01-01', 1, '2020-01-27', 'Lot1_Jan202020_055745PM.xlsx')
ERROR - 2020-01-27 12:49:47 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 556
ERROR - 2020-01-27 12:49:47 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 653
ERROR - 2020-01-27 12:49:48 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 747
ERROR - 2020-01-27 12:49:48 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 842
ERROR - 2020-01-27 12:49:48 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 938
ERROR - 2020-01-27 12:49:48 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 1039
ERROR - 2020-01-27 12:49:48 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 12:50:36 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 12:50:36 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:01:46 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:01:46 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:01:52 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:01:52 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:04:28 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:04:28 --> Query error: Unknown column 'file_name' in 'where clause' - Invalid query: SELECT count(*)
FROM `import_beneficiaries`
WHERE `file_name` = 'Lot1_Jan202020_055745PM.xlsx'
ERROR - 2020-01-27 13:05:50 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:08:06 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:08:07 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:13:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:13:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 106
ERROR - 2020-01-27 13:13:50 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:13:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 106
ERROR - 2020-01-27 13:14:27 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:14:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 106
ERROR - 2020-01-27 13:14:47 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:14:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 107
ERROR - 2020-01-27 13:14:57 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:14:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 107
ERROR - 2020-01-27 13:15:19 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:15:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 107
ERROR - 2020-01-27 13:17:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:17:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 108
ERROR - 2020-01-27 13:19:18 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:19:18 --> Severity: Notice --> Undefined index: count C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 110
ERROR - 2020-01-27 13:19:18 --> Severity: Notice --> Undefined index: count C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 117
ERROR - 2020-01-27 13:19:18 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:19:50 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:19:57 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:19:57 --> Severity: Notice --> Undefined index: count C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 110
ERROR - 2020-01-27 13:19:57 --> Severity: Notice --> Undefined index: count C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 117
ERROR - 2020-01-27 13:19:57 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:20:11 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:21:12 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:21:19 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:21:19 --> Severity: Notice --> Undefined index: count C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 110
ERROR - 2020-01-27 13:21:19 --> Severity: Notice --> Undefined index: count C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 117
ERROR - 2020-01-27 13:21:19 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:21:36 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:22:02 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:22:07 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:22:10 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 285
ERROR - 2020-01-27 13:22:13 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 390
ERROR - 2020-01-27 13:22:15 --> Query error: Duplicate entry '0-0' for key 'PRIMARY' - Invalid query: INSERT INTO `xls_import_job_placement` (`beneficiary_id`, `placement_type`, `sme_or_cpmpany_id`, `wage`, `consortium`, `EmploymentDate`, `End_Date`, `status`, `postdate`, `file_name`) VALUES ('0', 'Employment', '', '0', '', '1970-01-01', '1970-01-01', 1, '2020-01-27', 'Lot1_Jan202020_055745PM.xlsx')
ERROR - 2020-01-27 13:22:15 --> Query error: Duplicate entry '0-0' for key 'PRIMARY' - Invalid query: INSERT INTO `xls_import_job_placement` (`beneficiary_id`, `placement_type`, `sme_or_cpmpany_id`, `wage`, `consortium`, `EmploymentDate`, `End_Date`, `status`, `postdate`, `file_name`) VALUES ('0', '', '', '0', '', '1970-01-01', '1970-01-01', 1, '2020-01-27', 'Lot1_Jan202020_055745PM.xlsx')
ERROR - 2020-01-27 13:22:15 --> Query error: Duplicate entry '0-0' for key 'PRIMARY' - Invalid query: INSERT INTO `xls_import_job_placement` (`beneficiary_id`, `placement_type`, `sme_or_cpmpany_id`, `wage`, `consortium`, `EmploymentDate`, `End_Date`, `status`, `postdate`, `file_name`) VALUES ('0', '', '', '0', '', '2019-12-01', '2019-09-29', 1, '2020-01-27', 'Lot1_Jan202020_055745PM.xlsx')
ERROR - 2020-01-27 13:22:15 --> Query error: Duplicate entry '0-0' for key 'PRIMARY' - Invalid query: INSERT INTO `xls_import_job_placement` (`beneficiary_id`, `placement_type`, `sme_or_cpmpany_id`, `wage`, `consortium`, `EmploymentDate`, `End_Date`, `status`, `postdate`, `file_name`) VALUES ('0', 'Employment', '', '0', '', '1970-01-01', '1970-01-01', 1, '2020-01-27', 'Lot1_Jan202020_055745PM.xlsx')
ERROR - 2020-01-27 13:22:15 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 585
ERROR - 2020-01-27 13:22:15 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 682
ERROR - 2020-01-27 13:22:15 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 776
ERROR - 2020-01-27 13:22:15 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 871
ERROR - 2020-01-27 13:22:15 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 967
ERROR - 2020-01-27 13:22:15 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 1068
ERROR - 2020-01-27 13:22:16 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:22:23 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:22:24 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:22:48 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:22:51 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 285
ERROR - 2020-01-27 13:22:53 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 390
ERROR - 2020-01-27 13:22:55 --> Query error: Duplicate entry '0-0' for key 'PRIMARY' - Invalid query: INSERT INTO `xls_import_job_placement` (`beneficiary_id`, `placement_type`, `sme_or_cpmpany_id`, `wage`, `consortium`, `EmploymentDate`, `End_Date`, `status`, `postdate`, `file_name`) VALUES ('0', 'Employment', '', '0', '', '1970-01-01', '1970-01-01', 1, '2020-01-27', 'Lot10_Jan202020_055745PM - Copy.xlsx')
ERROR - 2020-01-27 13:22:55 --> Query error: Duplicate entry '0-0' for key 'PRIMARY' - Invalid query: INSERT INTO `xls_import_job_placement` (`beneficiary_id`, `placement_type`, `sme_or_cpmpany_id`, `wage`, `consortium`, `EmploymentDate`, `End_Date`, `status`, `postdate`, `file_name`) VALUES ('0', '', '', '0', '', '1970-01-01', '1970-01-01', 1, '2020-01-27', 'Lot10_Jan202020_055745PM - Copy.xlsx')
ERROR - 2020-01-27 13:22:55 --> Query error: Duplicate entry '0-0' for key 'PRIMARY' - Invalid query: INSERT INTO `xls_import_job_placement` (`beneficiary_id`, `placement_type`, `sme_or_cpmpany_id`, `wage`, `consortium`, `EmploymentDate`, `End_Date`, `status`, `postdate`, `file_name`) VALUES ('0', '', '', '0', '', '2019-12-01', '2019-09-29', 1, '2020-01-27', 'Lot10_Jan202020_055745PM - Copy.xlsx')
ERROR - 2020-01-27 13:22:55 --> Query error: Duplicate entry '0-0' for key 'PRIMARY' - Invalid query: INSERT INTO `xls_import_job_placement` (`beneficiary_id`, `placement_type`, `sme_or_cpmpany_id`, `wage`, `consortium`, `EmploymentDate`, `End_Date`, `status`, `postdate`, `file_name`) VALUES ('0', 'Employment', '', '0', '', '1970-01-01', '1970-01-01', 1, '2020-01-27', 'Lot10_Jan202020_055745PM - Copy.xlsx')
ERROR - 2020-01-27 13:22:55 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 585
ERROR - 2020-01-27 13:22:55 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 682
ERROR - 2020-01-27 13:22:55 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 776
ERROR - 2020-01-27 13:22:55 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 871
ERROR - 2020-01-27 13:22:55 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 967
ERROR - 2020-01-27 13:22:56 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 1068
ERROR - 2020-01-27 13:22:56 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:24:22 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:24:22 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ']' C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 104
ERROR - 2020-01-27 13:24:29 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:24:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:25:05 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:25:16 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:25:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:25:48 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:26:03 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:26:04 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:26:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:27:04 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:27:05 --> Severity: Warning --> print_r() expects parameter 2 to be boolean, array given C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 111
ERROR - 2020-01-27 13:27:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:27:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:27:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:27:45 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:27:51 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:27:51 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:28:22 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:28:28 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:28:28 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:28:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:28:37 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 291
ERROR - 2020-01-27 13:28:39 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 396
ERROR - 2020-01-27 13:28:40 --> Query error: Duplicate entry '0-0' for key 'PRIMARY' - Invalid query: INSERT INTO `xls_import_job_placement` (`beneficiary_id`, `placement_type`, `sme_or_cpmpany_id`, `wage`, `consortium`, `EmploymentDate`, `End_Date`, `status`, `postdate`, `file_name`) VALUES ('0', 'Employment', '', '0', '', '1970-01-01', '1970-01-01', 1, '2020-01-27', 'Lot1_Jan202020_055745PM.xlsx')
ERROR - 2020-01-27 13:28:40 --> Query error: Duplicate entry '0-0' for key 'PRIMARY' - Invalid query: INSERT INTO `xls_import_job_placement` (`beneficiary_id`, `placement_type`, `sme_or_cpmpany_id`, `wage`, `consortium`, `EmploymentDate`, `End_Date`, `status`, `postdate`, `file_name`) VALUES ('0', '', '', '0', '', '1970-01-01', '1970-01-01', 1, '2020-01-27', 'Lot1_Jan202020_055745PM.xlsx')
ERROR - 2020-01-27 13:28:40 --> Query error: Duplicate entry '0-0' for key 'PRIMARY' - Invalid query: INSERT INTO `xls_import_job_placement` (`beneficiary_id`, `placement_type`, `sme_or_cpmpany_id`, `wage`, `consortium`, `EmploymentDate`, `End_Date`, `status`, `postdate`, `file_name`) VALUES ('0', '', '', '0', '', '2019-12-01', '2019-09-29', 1, '2020-01-27', 'Lot1_Jan202020_055745PM.xlsx')
ERROR - 2020-01-27 13:28:40 --> Query error: Duplicate entry '0-0' for key 'PRIMARY' - Invalid query: INSERT INTO `xls_import_job_placement` (`beneficiary_id`, `placement_type`, `sme_or_cpmpany_id`, `wage`, `consortium`, `EmploymentDate`, `End_Date`, `status`, `postdate`, `file_name`) VALUES ('0', 'Employment', '', '0', '', '1970-01-01', '1970-01-01', 1, '2020-01-27', 'Lot1_Jan202020_055745PM.xlsx')
ERROR - 2020-01-27 13:28:40 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 591
ERROR - 2020-01-27 13:28:41 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 688
ERROR - 2020-01-27 13:28:41 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 782
ERROR - 2020-01-27 13:28:41 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 877
ERROR - 2020-01-27 13:28:41 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 973
ERROR - 2020-01-27 13:28:41 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 1074
ERROR - 2020-01-27 13:28:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:29:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 13:29:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 14:12:51 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 14:30:31 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 14:34:25 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 14:40:46 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 14:40:46 --> Query error: Table 'since_central_db_v2.lots_master' doesn't exist - Invalid query: SELECT lots_name,lots_id FROM `lots_master` 
ERROR - 2020-01-27 14:43:31 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 14:43:31 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 81
ERROR - 2020-01-27 14:43:31 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 81
ERROR - 2020-01-27 14:47:04 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 14:47:04 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\last3monthsunemployed.php 52
ERROR - 2020-01-27 14:47:04 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\last3monthsunemployed.php 52
ERROR - 2020-01-27 14:47:04 --> Severity: Notice --> Undefined variable: sqlvalusechain C:\danxampp\htdocs\since\application\modules\reports\views\last3monthsunemployed.php 165
ERROR - 2020-01-27 14:47:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\danxampp\htdocs\since\application\modules\reports\views\last3monthsunemployed.php 165
ERROR - 2020-01-27 14:47:04 --> Severity: Notice --> Undefined variable: tot_male1 C:\danxampp\htdocs\since\application\modules\reports\views\last3monthsunemployed.php 388
ERROR - 2020-01-27 14:47:04 --> Severity: Notice --> Undefined variable: tot_fmale1 C:\danxampp\htdocs\since\application\modules\reports\views\last3monthsunemployed.php 389
ERROR - 2020-01-27 14:47:04 --> Severity: Notice --> Undefined variable: tot_t1 C:\danxampp\htdocs\since\application\modules\reports\views\last3monthsunemployed.php 390
ERROR - 2020-01-27 14:47:04 --> Severity: Notice --> Undefined variable: tot_male1 C:\danxampp\htdocs\since\application\modules\reports\views\last3monthsunemployed.php 393
ERROR - 2020-01-27 14:47:04 --> Severity: Notice --> Undefined variable: tot_fmale1 C:\danxampp\htdocs\since\application\modules\reports\views\last3monthsunemployed.php 394
ERROR - 2020-01-27 14:47:04 --> Severity: Notice --> Undefined variable: tot_t1 C:\danxampp\htdocs\since\application\modules\reports\views\last3monthsunemployed.php 395
ERROR - 2020-01-27 14:51:32 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 14:51:32 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\last3monthsunemployed.php 52
ERROR - 2020-01-27 14:51:32 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\last3monthsunemployed.php 52
ERROR - 2020-01-27 14:51:32 --> Severity: Notice --> Undefined variable: sqlvalusechain C:\danxampp\htdocs\since\application\modules\reports\views\last3monthsunemployed.php 165
ERROR - 2020-01-27 14:51:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\danxampp\htdocs\since\application\modules\reports\views\last3monthsunemployed.php 165
ERROR - 2020-01-27 14:51:32 --> Severity: Notice --> Undefined variable: tot_male1 C:\danxampp\htdocs\since\application\modules\reports\views\last3monthsunemployed.php 388
ERROR - 2020-01-27 14:51:32 --> Severity: Notice --> Undefined variable: tot_fmale1 C:\danxampp\htdocs\since\application\modules\reports\views\last3monthsunemployed.php 389
ERROR - 2020-01-27 14:51:32 --> Severity: Notice --> Undefined variable: tot_t1 C:\danxampp\htdocs\since\application\modules\reports\views\last3monthsunemployed.php 390
ERROR - 2020-01-27 14:51:32 --> Severity: Notice --> Undefined variable: tot_male1 C:\danxampp\htdocs\since\application\modules\reports\views\last3monthsunemployed.php 393
ERROR - 2020-01-27 14:51:32 --> Severity: Notice --> Undefined variable: tot_fmale1 C:\danxampp\htdocs\since\application\modules\reports\views\last3monthsunemployed.php 394
ERROR - 2020-01-27 14:51:32 --> Severity: Notice --> Undefined variable: tot_t1 C:\danxampp\htdocs\since\application\modules\reports\views\last3monthsunemployed.php 395
ERROR - 2020-01-27 14:52:56 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 14:52:56 --> Query error: Unknown column 'job.employment_date' in 'where clause' - Invalid query: SELECT sme.`value_chain` from `import_smecompanies` AS sme 
   INNER JOIN
      import_job_placement AS job 
      ON job.sme_or_cpmpany_id = sme.enterprise_id 
   LEFT JOIN
      import_beneficiaries AS bene 
      ON bene.beneficiary_id = job.beneficiary_id 
where
   (
       Date(job.employment_date)>= (CURDATE() - INTERVAL 25 MONTH) 
   )
  
GROUP BY
   sme.`value_chain`
ERROR - 2020-01-27 14:54:54 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 14:54:55 --> Query error: Unknown column 'sme.value_chain' in 'group statement' - Invalid query: SELECT value_chain from xls_import_beneficiaries GROUP BY sme.`value_chain`
ERROR - 2020-01-27 14:55:11 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 14:55:11 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\last3monthsunemployed.php 52
ERROR - 2020-01-27 14:55:11 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\last3monthsunemployed.php 52
ERROR - 2020-01-27 14:55:11 --> Query error: Unknown column 'job1.employment_date' in 'where clause' - Invalid query: 
SELECT
  sme.`value_chain`,
   (
      SELECT
         Count(bene1.sex) 
      FROM
         `import_smecompanies` AS sme1 
         INNER JOIN
            import_job_placement AS job1 
            ON job1.sme_or_cpmpany_id = sme1.enterprise_id 
         LEFT JOIN
            import_beneficiaries AS bene1 
            ON bene1.beneficiary_id = job1.beneficiary_id 
      WHERE
         bene1.sex = 'Male' 
		 and bene1.Employed='FALSE'
       
         AND 
         (
         Date(job1.employment_date)>= (CURDATE() - INTERVAL 25 MONTH) 
         )
         AND sme1.`value_chain` = 'Construction' 
      GROUP BY
         sme1.`value_chain`
   )
   AS male,
   (
      SELECT
         Count(bene2.sex) 
      FROM
         `import_smecompanies` AS sme2 
         INNER JOIN
            import_job_placement AS job2 
            ON job2.sme_or_cpmpany_id = sme2.enterprise_id 
         LEFT JOIN
            import_beneficiaries AS bene2 
            ON bene2.beneficiary_id = job2.beneficiary_id 
      WHERE
         bene2.sex = 'Female' 
		  and bene2.Employed='FALSE'
      
         AND 
         (
            Date(job2.employment_date)>= (CURDATE() - INTERVAL 25 MONTH) 
         )
         AND sme2.`value_chain` = 'Construction' 
      GROUP BY
         sme2.`value_chain`
   )
   AS Female,
   Count(bene.sex) AS total 
FROM
   `import_smecompanies` AS sme 
   INNER JOIN
      import_job_placement AS job 
      ON job.sme_or_cpmpany_id = sme.enterprise_id 
   LEFT JOIN
      import_beneficiaries AS bene 
      ON bene.beneficiary_id = job.beneficiary_id 
where
   (
       Date(job.employment_date)>= (CURDATE() - INTERVAL 25 MONTH) 
   )
  
    and bene.Employed='FALSE'
and sme.`value_chain`='Construction'

ERROR - 2020-01-27 14:55:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 14:55:34 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\last3monthsunemployed.php 52
ERROR - 2020-01-27 14:55:34 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\last3monthsunemployed.php 52
ERROR - 2020-01-27 14:55:34 --> Query error: Unknown column 'job1.employment_date' in 'where clause' - Invalid query: 
SELECT
  sme.`value_chain`,
   (
      SELECT
         Count(bene1.sex) 
      FROM
         `import_smecompanies` AS sme1 
         INNER JOIN
            import_job_placement AS job1 
            ON job1.sme_or_cpmpany_id = sme1.enterprise_id 
         LEFT JOIN
            import_beneficiaries AS bene1 
            ON bene1.beneficiary_id = job1.beneficiary_id 
      WHERE
         bene1.sex = 'Male' 
		 and bene1.Employed='FALSE'
       
         AND 
         (
         Date(job1.employment_date)>= (CURDATE() - INTERVAL 25 MONTH) 
         )
         AND sme1.`value_chain` = 'Construction' 
      GROUP BY
         sme1.`value_chain`
   )
   AS male,
   (
      SELECT
         Count(bene2.sex) 
      FROM
         `import_smecompanies` AS sme2 
         INNER JOIN
            import_job_placement AS job2 
            ON job2.sme_or_cpmpany_id = sme2.enterprise_id 
         LEFT JOIN
            import_beneficiaries AS bene2 
            ON bene2.beneficiary_id = job2.beneficiary_id 
      WHERE
         bene2.sex = 'Female' 
		  and bene2.Employed='FALSE'
      
         AND 
         (
            Date(job2.employment_date)>= (CURDATE() - INTERVAL 25 MONTH) 
         )
         AND sme2.`value_chain` = 'Construction' 
      GROUP BY
         sme2.`value_chain`
   )
   AS Female,
   Count(bene.sex) AS total 
FROM
   `import_smecompanies` AS sme 
   INNER JOIN
      import_job_placement AS job 
      ON job.sme_or_cpmpany_id = sme.enterprise_id 
   LEFT JOIN
      import_beneficiaries AS bene 
      ON bene.beneficiary_id = job.beneficiary_id 
where
   (
       Date(job.employment_date)>= (CURDATE() - INTERVAL 25 MONTH) 
   )
  
    and bene.Employed='FALSE'
and sme.`value_chain`='Construction'

ERROR - 2020-01-27 14:57:15 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 14:57:15 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\last3monthsunemployed.php 52
ERROR - 2020-01-27 14:57:15 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\last3monthsunemployed.php 52
ERROR - 2020-01-27 14:57:15 --> Severity: Notice --> Undefined variable: val C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\last3monthsunemployed.php 173
ERROR - 2020-01-27 14:57:15 --> Severity: Notice --> Undefined variable: val C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\last3monthsunemployed.php 174
ERROR - 2020-01-27 14:57:15 --> Severity: Notice --> Undefined variable: val C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\last3monthsunemployed.php 175
ERROR - 2020-01-27 14:57:15 --> Severity: Notice --> Undefined variable: val1 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\last3monthsunemployed.php 178
ERROR - 2020-01-27 14:57:15 --> Severity: Notice --> Undefined variable: val1 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\last3monthsunemployed.php 179
ERROR - 2020-01-27 14:57:15 --> Severity: Notice --> Undefined variable: val1 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\last3monthsunemployed.php 180
ERROR - 2020-01-27 14:57:15 --> Severity: Notice --> Undefined variable: val C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\last3monthsunemployed.php 184
ERROR - 2020-01-27 14:57:15 --> Severity: Notice --> Undefined variable: val1 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\last3monthsunemployed.php 184
ERROR - 2020-01-27 14:57:15 --> Severity: Notice --> Undefined variable: val C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\last3monthsunemployed.php 185
ERROR - 2020-01-27 14:57:15 --> Severity: Notice --> Undefined variable: val1 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\last3monthsunemployed.php 185
ERROR - 2020-01-27 14:57:15 --> Severity: Notice --> Undefined variable: val C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\last3monthsunemployed.php 173
ERROR - 2020-01-27 14:57:15 --> Severity: Notice --> Undefined variable: val C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\last3monthsunemployed.php 174
ERROR - 2020-01-27 14:57:15 --> Severity: Notice --> Undefined variable: val C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\last3monthsunemployed.php 175
ERROR - 2020-01-27 14:57:15 --> Severity: Notice --> Undefined variable: val1 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\last3monthsunemployed.php 178
ERROR - 2020-01-27 14:57:15 --> Severity: Notice --> Undefined variable: val1 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\last3monthsunemployed.php 179
ERROR - 2020-01-27 14:57:15 --> Severity: Notice --> Undefined variable: val1 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\last3monthsunemployed.php 180
ERROR - 2020-01-27 14:57:15 --> Severity: Notice --> Undefined variable: val C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\last3monthsunemployed.php 184
ERROR - 2020-01-27 14:57:15 --> Severity: Notice --> Undefined variable: val1 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\last3monthsunemployed.php 184
ERROR - 2020-01-27 14:57:15 --> Severity: Notice --> Undefined variable: val C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\last3monthsunemployed.php 185
ERROR - 2020-01-27 14:57:15 --> Severity: Notice --> Undefined variable: val1 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\last3monthsunemployed.php 185
ERROR - 2020-01-27 14:57:15 --> Severity: Notice --> Undefined variable: val C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\last3monthsunemployed.php 173
ERROR - 2020-01-27 14:57:15 --> Severity: Notice --> Undefined variable: val C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\last3monthsunemployed.php 174
ERROR - 2020-01-27 14:57:15 --> Severity: Notice --> Undefined variable: val C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\last3monthsunemployed.php 175
ERROR - 2020-01-27 14:57:15 --> Severity: Notice --> Undefined variable: val1 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\last3monthsunemployed.php 178
ERROR - 2020-01-27 14:57:15 --> Severity: Notice --> Undefined variable: val1 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\last3monthsunemployed.php 179
ERROR - 2020-01-27 14:57:15 --> Severity: Notice --> Undefined variable: val1 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\last3monthsunemployed.php 180
ERROR - 2020-01-27 14:57:15 --> Severity: Notice --> Undefined variable: val C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\last3monthsunemployed.php 184
ERROR - 2020-01-27 14:57:15 --> Severity: Notice --> Undefined variable: val1 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\last3monthsunemployed.php 184
ERROR - 2020-01-27 14:57:15 --> Severity: Notice --> Undefined variable: val C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\last3monthsunemployed.php 185
ERROR - 2020-01-27 14:57:15 --> Severity: Notice --> Undefined variable: val1 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\last3monthsunemployed.php 185
ERROR - 2020-01-27 14:57:15 --> Severity: Notice --> Undefined variable: tot_male1 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\last3monthsunemployed.php 198
ERROR - 2020-01-27 14:57:15 --> Severity: Notice --> Undefined variable: tot_fmale1 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\last3monthsunemployed.php 199
ERROR - 2020-01-27 14:57:15 --> Severity: Notice --> Undefined variable: tot_t1 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\last3monthsunemployed.php 200
ERROR - 2020-01-27 14:57:15 --> Severity: Notice --> Undefined variable: tot_t1 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\last3monthsunemployed.php 202
ERROR - 2020-01-27 14:57:48 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 14:58:25 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 14:58:40 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 14:59:05 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 14:59:29 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 14:59:48 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 14:59:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 15:00:28 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 15:01:23 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 15:01:40 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 15:02:15 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 15:02:32 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 15:04:14 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 15:04:51 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 15:05:09 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 15:05:36 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 15:05:50 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 15:05:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 15:06:05 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 15:06:38 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 15:10:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 15:11:02 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 15:11:21 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 15:11:29 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 15:11:37 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 15:11:46 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 15:11:50 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 15:11:52 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 15:11:54 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 15:11:56 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 15:32:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 15:32:46 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 15:32:46 --> Query error: Unknown column 'lots_master' in 'where clause' - Invalid query: SELECT count(*) as count
FROM `lots_master`
WHERE `lots_master` = 'Lot1'
AND `status` = 1
ERROR - 2020-01-27 15:33:31 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 15:33:31 --> Query error: Unknown column 'status' in 'where clause' - Invalid query: SELECT count(*) as count
FROM `lots_master`
WHERE `lots_id` = 'Lot1'
AND `status` = 1
ERROR - 2020-01-27 15:33:51 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 15:33:51 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 15:34:21 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 15:34:24 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 291
ERROR - 2020-01-27 15:34:26 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 396
ERROR - 2020-01-27 15:34:28 --> Query error: Duplicate entry '0-0' for key 'PRIMARY' - Invalid query: INSERT INTO `xls_import_job_placement` (`beneficiary_id`, `placement_type`, `sme_or_cpmpany_id`, `wage`, `consortium`, `EmploymentDate`, `End_Date`, `status`, `postdate`, `file_name`) VALUES ('0', 'Employment', '', '0', '', '1970-01-01', '1970-01-01', 1, '2020-01-27', 'Lot1_Jan202020_055745PM.xlsx')
ERROR - 2020-01-27 15:34:28 --> Query error: Duplicate entry '0-0' for key 'PRIMARY' - Invalid query: INSERT INTO `xls_import_job_placement` (`beneficiary_id`, `placement_type`, `sme_or_cpmpany_id`, `wage`, `consortium`, `EmploymentDate`, `End_Date`, `status`, `postdate`, `file_name`) VALUES ('0', '', '', '0', '', '1970-01-01', '1970-01-01', 1, '2020-01-27', 'Lot1_Jan202020_055745PM.xlsx')
ERROR - 2020-01-27 15:34:28 --> Query error: Duplicate entry '0-0' for key 'PRIMARY' - Invalid query: INSERT INTO `xls_import_job_placement` (`beneficiary_id`, `placement_type`, `sme_or_cpmpany_id`, `wage`, `consortium`, `EmploymentDate`, `End_Date`, `status`, `postdate`, `file_name`) VALUES ('0', '', '', '0', '', '2019-12-01', '2019-09-29', 1, '2020-01-27', 'Lot1_Jan202020_055745PM.xlsx')
ERROR - 2020-01-27 15:34:28 --> Query error: Duplicate entry '0-0' for key 'PRIMARY' - Invalid query: INSERT INTO `xls_import_job_placement` (`beneficiary_id`, `placement_type`, `sme_or_cpmpany_id`, `wage`, `consortium`, `EmploymentDate`, `End_Date`, `status`, `postdate`, `file_name`) VALUES ('0', 'Employment', '', '0', '', '1970-01-01', '1970-01-01', 1, '2020-01-27', 'Lot1_Jan202020_055745PM.xlsx')
ERROR - 2020-01-27 15:34:28 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 591
ERROR - 2020-01-27 15:34:28 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 688
ERROR - 2020-01-27 15:34:28 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 782
ERROR - 2020-01-27 15:34:28 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 877
ERROR - 2020-01-27 15:34:28 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 973
ERROR - 2020-01-27 15:34:28 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 1074
ERROR - 2020-01-27 15:34:29 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 15:41:40 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 16:14:31 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 16:24:42 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 16:59:09 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 16:59:09 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\last3monthsunemployed.php 241
ERROR - 2020-01-27 16:59:15 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 17:02:19 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 17:04:29 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 17:05:04 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 17:05:13 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 17:05:53 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 17:06:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 17:07:12 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 17:07:14 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 17:08:32 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 17:08:47 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 17:08:47 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\overall_objective_report.php 52
ERROR - 2020-01-27 17:08:47 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\overall_objective_report.php 52
ERROR - 2020-01-27 17:08:47 --> Severity: Notice --> Undefined variable: sqlregions C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\overall_objective_report.php 155
ERROR - 2020-01-27 17:08:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\overall_objective_report.php 155
ERROR - 2020-01-27 17:08:47 --> Severity: Notice --> Undefined variable: val C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\overall_objective_report.php 272
ERROR - 2020-01-27 17:08:47 --> Severity: Notice --> Undefined variable: val C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\overall_objective_report.php 273
ERROR - 2020-01-27 17:08:47 --> Severity: Notice --> Undefined variable: val C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\overall_objective_report.php 278
ERROR - 2020-01-27 17:08:47 --> Severity: Notice --> Undefined variable: val C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\overall_objective_report.php 279
ERROR - 2020-01-27 17:08:47 --> Severity: Notice --> Undefined variable: tot_male1 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\overall_objective_report.php 280
ERROR - 2020-01-27 17:08:47 --> Severity: Notice --> Undefined variable: tot_fmale1 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\overall_objective_report.php 281
ERROR - 2020-01-27 17:08:47 --> Severity: Notice --> Undefined variable: tot_t1 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\overall_objective_report.php 282
ERROR - 2020-01-27 17:08:47 --> Severity: Notice --> Undefined variable: tot_t1 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\overall_objective_report.php 284
ERROR - 2020-01-27 17:09:22 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 17:09:22 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\overall_objective_report.php 52
ERROR - 2020-01-27 17:09:22 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\overall_objective_report.php 52
ERROR - 2020-01-27 17:09:22 --> Severity: Notice --> Undefined variable: sqlregions C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\overall_objective_report.php 155
ERROR - 2020-01-27 17:09:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\overall_objective_report.php 155
ERROR - 2020-01-27 17:09:22 --> Severity: Notice --> Undefined variable: val C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\overall_objective_report.php 274
ERROR - 2020-01-27 17:09:22 --> Severity: Notice --> Undefined variable: val C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\overall_objective_report.php 275
ERROR - 2020-01-27 17:09:22 --> Severity: Notice --> Undefined variable: val C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\overall_objective_report.php 280
ERROR - 2020-01-27 17:09:22 --> Severity: Notice --> Undefined variable: val C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\overall_objective_report.php 281
ERROR - 2020-01-27 17:09:22 --> Severity: Notice --> Undefined variable: tot_male1 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\overall_objective_report.php 282
ERROR - 2020-01-27 17:09:22 --> Severity: Notice --> Undefined variable: tot_fmale1 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\overall_objective_report.php 283
ERROR - 2020-01-27 17:09:22 --> Severity: Notice --> Undefined variable: tot_t1 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\overall_objective_report.php 284
ERROR - 2020-01-27 17:09:22 --> Severity: Notice --> Undefined variable: tot_t1 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\overall_objective_report.php 286
ERROR - 2020-01-27 17:09:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 17:09:44 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 17:10:00 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 17:11:29 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 17:11:48 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 17:11:57 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 17:17:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 17:18:25 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 17:18:46 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 18:20:47 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 18:20:47 --> Severity: error --> Exception: syntax error, unexpected 'as' (T_AS), expecting ';' C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\overall_objective_report.php 244
ERROR - 2020-01-27 18:23:48 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 18:23:48 --> Severity: error --> Exception: syntax error, unexpected 'as' (T_AS), expecting ';' C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\overall_objective_report.php 244
ERROR - 2020-01-27 18:24:09 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 18:25:44 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 18:26:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 18:46:46 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 18:48:28 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 18:49:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 18:49:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 19:03:05 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 19:06:31 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 19:06:52 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 19:06:57 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 19:09:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 19:09:45 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 19:12:47 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 19:12:53 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 19:15:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 19:15:47 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 19:15:53 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 19:18:00 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 19:18:04 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 19:18:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '='Lot1' GROUP BY `lots_id`' at line 1 - Invalid query: SELECT lots_name,lots_id FROM `lots_master` lots_id='Lot1' GROUP BY `lots_id` 
ERROR - 2020-01-27 19:18:16 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 19:18:18 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 19:31:10 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 19:31:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 19:31:34 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report\overall_objective_report.php 400
ERROR - 2020-01-27 19:31:44 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 19:36:07 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 19:36:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 19:36:20 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 19:39:19 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 19:41:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 19:41:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 19:41:38 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 19:42:25 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 19:42:28 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 19:42:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 19:44:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 19:44:44 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 19:44:53 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 19:45:52 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 19:47:07 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 19:47:52 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 19:50:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 19:51:19 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 19:53:28 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 19:55:48 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 19:56:27 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 19:56:49 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 19:58:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 19:59:12 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 19:59:50 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:00:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:00:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:00:35 --> 404 Page Not Found: ../modules/importdb/controllers/Importdb/uploadcsv
ERROR - 2020-01-27 20:00:54 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:00:55 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:01:27 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:02:42 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:02:45 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:02:54 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:04:26 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:04:31 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:04:40 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:04:51 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:05:11 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:05:15 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:05:21 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:05:24 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:05:28 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:05:47 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:05:48 --> Query error: Duplicate entry 'mohddanish8564@gmail.com' for key 'email' - Invalid query: INSERT INTO `user_login` (`firstname`, `lastname`, `gender`, `email`, `mobile_no`, `role`, `pass`, `status`, `post_date`) VALUES ('Abcde', 'fgh', 'male', 'mohddanish8564@gmail.com', '8564957155', '2', '202cb962ac59075b964b07152d234b70', 1, '2020-01-27')
ERROR - 2020-01-27 20:05:48 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:06:10 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:06:10 --> Query error: Duplicate entry '8299226971' for key 'mobile_no' - Invalid query: INSERT INTO `user_login` (`firstname`, `lastname`, `gender`, `email`, `mobile_no`, `role`, `pass`, `status`, `post_date`) VALUES ('danish', 'ali', 'male', 'pop@gmail.com', '8299226971', '2', '202cb962ac59075b964b07152d234b70', 1, '2020-01-27')
ERROR - 2020-01-27 20:06:10 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:06:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:06:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:06:38 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:06:47 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:06:47 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:06:56 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:06:56 --> 404 Page Not Found: /index
ERROR - 2020-01-27 20:06:58 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:06:58 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:07:07 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:07:07 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:07:11 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:07:11 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:07:13 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:07:13 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:07:24 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:07:24 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:07:40 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:07:40 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:07:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:07:46 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:10:13 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:10:15 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:10:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:10:18 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:10:18 --> 404 Page Not Found: /index
ERROR - 2020-01-27 20:10:21 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:10:21 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:10:32 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:10:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:10:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:13:25 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:13:25 --> 404 Page Not Found: /index
ERROR - 2020-01-27 20:13:27 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:13:27 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:13:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:13:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:13:36 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:13:36 --> 404 Page Not Found: /index
ERROR - 2020-01-27 20:13:38 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:13:38 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:13:47 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:13:47 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:13:55 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:13:55 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:13:58 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:13:58 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:14:01 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:14:38 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:14:38 --> 404 Page Not Found: /index
ERROR - 2020-01-27 20:14:40 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:14:40 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:14:45 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:16:06 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-27 20:16:06 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
