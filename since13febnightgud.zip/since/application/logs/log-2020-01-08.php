<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-08 11:11:27 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 11:11:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 11:11:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 11:11:37 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 14:59:11 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 14:59:12 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 14:59:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 14:59:40 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 14:59:40 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 14:59:52 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:00:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:03:06 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:03:06 --> Severity: Notice --> Undefined variable: types C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 6
ERROR - 2020-01-08 15:03:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 6
ERROR - 2020-01-08 15:03:06 --> Severity: Notice --> Undefined variable: types C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 10
ERROR - 2020-01-08 15:03:12 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:03:12 --> Severity: Notice --> Undefined variable: types C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 6
ERROR - 2020-01-08 15:03:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 6
ERROR - 2020-01-08 15:03:12 --> Severity: Notice --> Undefined variable: types C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 10
ERROR - 2020-01-08 15:05:21 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:05:21 --> Severity: Notice --> Array to string conversion C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 6
ERROR - 2020-01-08 15:05:21 --> Severity: Notice --> Array to string conversion C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 6
ERROR - 2020-01-08 15:05:21 --> Severity: Notice --> Array to string conversion C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 6
ERROR - 2020-01-08 15:05:21 --> Severity: Notice --> Undefined index: value_chain C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 8
ERROR - 2020-01-08 15:05:21 --> Severity: Warning --> A non-numeric value encountered C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 8
ERROR - 2020-01-08 15:05:21 --> Severity: Notice --> Undefined variable: types C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 8
ERROR - 2020-01-08 15:05:21 --> Severity: Notice --> Undefined index: value_chain C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 8
ERROR - 2020-01-08 15:05:21 --> Severity: Warning --> A non-numeric value encountered C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 8
ERROR - 2020-01-08 15:05:21 --> Severity: Notice --> Undefined index: value_chain C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 8
ERROR - 2020-01-08 15:05:21 --> Severity: Warning --> A non-numeric value encountered C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 8
ERROR - 2020-01-08 15:05:38 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:05:38 --> Severity: Notice --> Undefined index: value_chain C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 8
ERROR - 2020-01-08 15:05:38 --> Severity: Warning --> A non-numeric value encountered C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 8
ERROR - 2020-01-08 15:05:38 --> Severity: Notice --> Undefined index: value_chain C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 8
ERROR - 2020-01-08 15:05:38 --> Severity: Warning --> A non-numeric value encountered C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 8
ERROR - 2020-01-08 15:05:38 --> Severity: Notice --> Undefined index: value_chain C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 8
ERROR - 2020-01-08 15:05:38 --> Severity: Warning --> A non-numeric value encountered C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 8
ERROR - 2020-01-08 15:05:52 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:05:52 --> Severity: Warning --> A non-numeric value encountered C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 8
ERROR - 2020-01-08 15:05:52 --> Severity: Warning --> A non-numeric value encountered C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 8
ERROR - 2020-01-08 15:05:52 --> Severity: Warning --> A non-numeric value encountered C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 8
ERROR - 2020-01-08 15:05:52 --> Severity: Warning --> A non-numeric value encountered C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 8
ERROR - 2020-01-08 15:05:52 --> Severity: Warning --> A non-numeric value encountered C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 8
ERROR - 2020-01-08 15:05:52 --> Severity: Warning --> A non-numeric value encountered C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 8
ERROR - 2020-01-08 15:05:54 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:05:54 --> Severity: Warning --> A non-numeric value encountered C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 8
ERROR - 2020-01-08 15:05:54 --> Severity: Warning --> A non-numeric value encountered C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 8
ERROR - 2020-01-08 15:05:54 --> Severity: Warning --> A non-numeric value encountered C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 8
ERROR - 2020-01-08 15:05:54 --> Severity: Warning --> A non-numeric value encountered C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 8
ERROR - 2020-01-08 15:05:54 --> Severity: Warning --> A non-numeric value encountered C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 8
ERROR - 2020-01-08 15:05:54 --> Severity: Warning --> A non-numeric value encountered C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 8
ERROR - 2020-01-08 15:05:54 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:05:54 --> Severity: Warning --> A non-numeric value encountered C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 8
ERROR - 2020-01-08 15:05:54 --> Severity: Warning --> A non-numeric value encountered C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 8
ERROR - 2020-01-08 15:05:54 --> Severity: Warning --> A non-numeric value encountered C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 8
ERROR - 2020-01-08 15:05:54 --> Severity: Warning --> A non-numeric value encountered C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 8
ERROR - 2020-01-08 15:05:54 --> Severity: Warning --> A non-numeric value encountered C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 8
ERROR - 2020-01-08 15:05:54 --> Severity: Warning --> A non-numeric value encountered C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 8
ERROR - 2020-01-08 15:06:19 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:06:27 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:06:48 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:07:38 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:07:56 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:08:00 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:10:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:10:08 --> Severity: error --> Exception: syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting '-' or identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 26
ERROR - 2020-01-08 15:10:32 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:10:32 --> Severity: error --> Exception: syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting '-' or identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 26
ERROR - 2020-01-08 15:11:04 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:11:18 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:11:18 --> Severity: Notice --> Array to string conversion C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 26
ERROR - 2020-01-08 15:11:18 --> Severity: Notice --> Array to string conversion C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 26
ERROR - 2020-01-08 15:11:18 --> Severity: Notice --> Array to string conversion C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 26
ERROR - 2020-01-08 15:11:23 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:11:23 --> Severity: Notice --> Array to string conversion C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 26
ERROR - 2020-01-08 15:11:23 --> Severity: Notice --> Array to string conversion C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 26
ERROR - 2020-01-08 15:11:23 --> Severity: Notice --> Array to string conversion C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 26
ERROR - 2020-01-08 15:11:53 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:11:53 --> Severity: Notice --> Array to string conversion C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 26
ERROR - 2020-01-08 15:11:53 --> Severity: Notice --> Array to string conversion C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 26
ERROR - 2020-01-08 15:11:53 --> Severity: Notice --> Array to string conversion C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 26
ERROR - 2020-01-08 15:12:13 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:12:49 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:13:24 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:15:05 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:20:37 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:20:37 --> Severity: error --> Exception: Call to undefined function findpercent() C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 11
ERROR - 2020-01-08 15:20:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:20:39 --> Severity: error --> Exception: Call to undefined function findpercent() C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 11
ERROR - 2020-01-08 15:20:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:20:39 --> Severity: error --> Exception: Call to undefined function findpercent() C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 11
ERROR - 2020-01-08 15:20:53 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:20:53 --> Severity: error --> Exception: Call to undefined method MY_Loader::findpercent() C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 11
ERROR - 2020-01-08 15:21:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:21:33 --> Severity: error --> Exception: Call to undefined method MY_Loader::findpercent() C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 11
ERROR - 2020-01-08 15:21:38 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:21:38 --> Severity: error --> Exception: Call to undefined method MY_Loader::findpercent() C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 11
ERROR - 2020-01-08 15:22:52 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:22:52 --> Severity: error --> Exception: syntax error, unexpected ')', expecting variable (T_VARIABLE) C:\danxampp\htdocs\demo\application\helpers\funcus_helper.php 740
ERROR - 2020-01-08 15:23:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:23:08 --> Severity: error --> Exception: syntax error, unexpected ')', expecting variable (T_VARIABLE) C:\danxampp\htdocs\demo\application\helpers\funcus_helper.php 740
ERROR - 2020-01-08 15:23:26 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:23:26 --> Severity: error --> Exception: syntax error, unexpected ')', expecting variable (T_VARIABLE) C:\danxampp\htdocs\demo\application\helpers\funcus_helper.php 740
ERROR - 2020-01-08 15:23:42 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:23:50 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:24:26 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:24:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:24:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:24:52 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:29:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:29:42 --> Severity: Notice --> Undefined variable: per C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 12
ERROR - 2020-01-08 15:29:42 --> Severity: error --> Exception: Too few arguments to function findpercent(), 1 passed in C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php on line 15 and exactly 2 expected C:\danxampp\htdocs\demo\application\helpers\funcus_helper.php 740
ERROR - 2020-01-08 15:29:54 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:29:54 --> Severity: error --> Exception: Too few arguments to function findpercent(), 1 passed in C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php on line 15 and exactly 2 expected C:\danxampp\htdocs\demo\application\helpers\funcus_helper.php 740
ERROR - 2020-01-08 15:30:14 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:30:14 --> Severity: error --> Exception: syntax error, unexpected ',' C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 15
ERROR - 2020-01-08 15:30:26 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:30:26 --> Severity: Notice --> A non well formed numeric value encountered C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 16
ERROR - 2020-01-08 15:30:26 --> Severity: Notice --> A non well formed numeric value encountered C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 16
ERROR - 2020-01-08 15:30:26 --> Severity: Notice --> A non well formed numeric value encountered C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 16
ERROR - 2020-01-08 15:31:07 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:31:07 --> Severity: Notice --> Undefined variable: totalPer C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 29
ERROR - 2020-01-08 15:31:07 --> Severity: Notice --> Undefined variable: totalPer C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 29
ERROR - 2020-01-08 15:31:07 --> Severity: Notice --> Undefined variable: totalPer C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 29
ERROR - 2020-01-08 15:31:27 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:32:04 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:32:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:34:58 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:35:26 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:35:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:35:46 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:36:27 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:38:00 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:39:03 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:41:15 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:49:28 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:55:38 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:55:54 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 15:56:04 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 16:01:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 16:02:03 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 16:02:47 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 16:28:49 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 17:14:01 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 17:14:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 17:14:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 17:14:08 --> Severity: Notice --> Undefined variable: chaina C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 157
ERROR - 2020-01-08 17:14:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 157
ERROR - 2020-01-08 17:15:25 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 17:15:25 --> Severity: error --> Exception: syntax error, unexpected ',' C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 180
ERROR - 2020-01-08 17:16:18 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 17:16:18 --> Severity: error --> Exception: syntax error, unexpected ',' C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 180
ERROR - 2020-01-08 17:16:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 17:16:33 --> Severity: Notice --> Undefined variable: chaina C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 157
ERROR - 2020-01-08 17:16:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 157
ERROR - 2020-01-08 17:16:58 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 17:16:58 --> Severity: Notice --> Undefined variable: chaina C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 157
ERROR - 2020-01-08 17:16:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 157
ERROR - 2020-01-08 17:17:00 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 17:17:00 --> Severity: Notice --> Undefined variable: chaina C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 157
ERROR - 2020-01-08 17:17:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 157
ERROR - 2020-01-08 17:17:32 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 17:18:00 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 17:18:13 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 17:18:21 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 17:19:03 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 17:19:24 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 17:19:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 17:21:05 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 17:22:56 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 17:23:15 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 17:24:02 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 17:24:13 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 17:24:31 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 17:25:12 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 17:25:20 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 17:25:20 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 17:25:20 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 17:25:20 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 17:25:47 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 18:29:09 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 18:30:00 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 18:30:07 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 18:32:14 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 18:32:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 18:39:52 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 18:39:53 --> Severity: Notice --> Undefined variable: fem C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 138
ERROR - 2020-01-08 18:39:53 --> Severity: Notice --> Undefined variable: male C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 139
ERROR - 2020-01-08 18:39:53 --> Severity: Notice --> Undefined variable: ch C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 140
ERROR - 2020-01-08 18:39:53 --> Severity: Notice --> Undefined variable: tot C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 141
ERROR - 2020-01-08 18:41:10 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 18:41:10 --> Severity: Notice --> Undefined variable: male C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 140
ERROR - 2020-01-08 18:41:10 --> Severity: Notice --> Undefined variable: ch C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 141
ERROR - 2020-01-08 18:41:10 --> Severity: Notice --> Undefined variable: tot C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 142
ERROR - 2020-01-08 18:41:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 18:41:34 --> Severity: Notice --> Undefined variable: ch C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 141
ERROR - 2020-01-08 18:41:34 --> Severity: Notice --> Undefined variable: tot C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 142
ERROR - 2020-01-08 18:41:42 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 18:41:42 --> Severity: Notice --> Undefined variable: tot C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 142
ERROR - 2020-01-08 18:41:50 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 18:45:40 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 18:52:24 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 18:53:07 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 18:53:07 --> Severity: Notice --> Undefined variable: fem C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 138
ERROR - 2020-01-08 18:53:07 --> Severity: Notice --> Undefined variable: male C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 139
ERROR - 2020-01-08 18:53:07 --> Severity: Notice --> Undefined variable: ch C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 140
ERROR - 2020-01-08 18:53:07 --> Severity: Notice --> Undefined variable: tot C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 141
ERROR - 2020-01-08 18:53:07 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-08 18:53:07 --> Severity: Notice --> Undefined variable: fem C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 138
ERROR - 2020-01-08 18:53:07 --> Severity: Notice --> Undefined variable: male C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 139
ERROR - 2020-01-08 18:53:07 --> Severity: Notice --> Undefined variable: ch C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 140
ERROR - 2020-01-08 18:53:07 --> Severity: Notice --> Undefined variable: tot C:\danxampp\htdocs\demo\application\modules\admindashboard\views\custom-dashboard.php 141
ERROR - 2020-01-08 18:55:37 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
