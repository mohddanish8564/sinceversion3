<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-29 11:22:19 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 11:22:23 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 11:22:23 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 11:22:27 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 11:22:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 11:23:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 11:24:37 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 11:24:45 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 11:25:05 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 11:29:29 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 11:29:29 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 81
ERROR - 2020-01-29 11:29:29 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 81
ERROR - 2020-01-29 11:34:38 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 11:34:38 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 81
ERROR - 2020-01-29 11:34:38 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 81
ERROR - 2020-01-29 11:34:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 11:34:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 11:35:19 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 100
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 100
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined variable: totalrowsum C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 428
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 296
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 297
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 298
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 299
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 300
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 309
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 309
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 312
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 312
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 315
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 315
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 318
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 318
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 321
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 321
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 396
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 397
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 398
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 399
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 400
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 409
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 409
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 412
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 412
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 415
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 415
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 418
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 418
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 421
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 421
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 600
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 601
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 602
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 603
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 604
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 613
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 613
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 616
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 616
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 619
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 619
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 622
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 622
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 625
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 625
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 700
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 701
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 702
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 703
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 704
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 713
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 713
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 716
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 716
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 719
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 719
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 722
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 722
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 725
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 725
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 905
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 906
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 907
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 908
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 909
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 918
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 918
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 921
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 921
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 924
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 924
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 927
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 927
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 930
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 930
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1005
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1006
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1007
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1008
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1009
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1018
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1018
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1021
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1021
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1024
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1024
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1027
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1027
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1030
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1030
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1211
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1212
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1213
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1214
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1215
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1224
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1224
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1227
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1227
ERROR - 2020-01-29 11:35:19 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1230
ERROR - 2020-01-29 11:35:20 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1230
ERROR - 2020-01-29 11:35:20 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1233
ERROR - 2020-01-29 11:35:20 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1233
ERROR - 2020-01-29 11:35:20 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1236
ERROR - 2020-01-29 11:35:20 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1236
ERROR - 2020-01-29 11:35:20 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1311
ERROR - 2020-01-29 11:35:20 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1312
ERROR - 2020-01-29 11:35:20 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1313
ERROR - 2020-01-29 11:35:20 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1314
ERROR - 2020-01-29 11:35:20 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1315
ERROR - 2020-01-29 11:35:20 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1324
ERROR - 2020-01-29 11:35:20 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1324
ERROR - 2020-01-29 11:35:20 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1327
ERROR - 2020-01-29 11:35:20 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1327
ERROR - 2020-01-29 11:35:20 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1330
ERROR - 2020-01-29 11:35:20 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1330
ERROR - 2020-01-29 11:35:20 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1333
ERROR - 2020-01-29 11:35:20 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1333
ERROR - 2020-01-29 11:35:20 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1336
ERROR - 2020-01-29 11:35:20 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1336
ERROR - 2020-01-29 11:35:20 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1488
ERROR - 2020-01-29 11:35:20 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1491
ERROR - 2020-01-29 11:35:20 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1494
ERROR - 2020-01-29 11:35:20 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1497
ERROR - 2020-01-29 11:35:20 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1500
ERROR - 2020-01-29 11:35:20 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1503
ERROR - 2020-01-29 11:35:20 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1506
ERROR - 2020-01-29 11:35:20 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1509
ERROR - 2020-01-29 11:35:20 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1616
ERROR - 2020-01-29 11:35:20 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1619
ERROR - 2020-01-29 11:35:20 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1622
ERROR - 2020-01-29 11:35:20 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1625
ERROR - 2020-01-29 11:35:27 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 11:35:27 --> Severity: Notice --> Undefined variable: totalrowsum C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 428
ERROR - 2020-01-29 11:35:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 296
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 297
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 298
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 299
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 300
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 309
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 309
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 312
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 312
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 315
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 315
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 318
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 318
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 321
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 321
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 396
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 397
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 398
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 399
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 400
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 409
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 409
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 412
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 412
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 415
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 415
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 418
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 418
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 421
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 421
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined variable: totalrowsum C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 428
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 600
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 601
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 602
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 603
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 604
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 613
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 613
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 616
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 616
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 619
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 619
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 622
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 622
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 625
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 625
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 700
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 701
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 702
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 703
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 704
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 713
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 713
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 716
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 716
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 719
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 719
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 722
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 722
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 725
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 725
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 905
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 906
ERROR - 2020-01-29 11:35:33 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 907
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 908
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 909
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 918
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 918
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 921
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 921
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 924
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 924
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 927
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 927
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 930
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 930
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1005
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1006
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1007
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1008
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1009
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1018
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1018
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1021
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1021
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1024
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1024
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1027
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1027
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1030
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1030
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1211
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1212
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1213
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1214
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1215
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1224
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1224
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1227
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1227
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1230
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1230
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1233
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1233
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1236
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1236
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1311
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1312
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1313
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1314
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1315
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1324
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1324
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1327
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1327
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1330
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1330
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1333
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1333
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1336
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1336
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1488
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1491
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1494
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1497
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1500
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1503
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1506
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1509
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1616
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1619
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1622
ERROR - 2020-01-29 11:35:34 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1625
ERROR - 2020-01-29 11:35:46 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined variable: totalrowsum C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 428
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 296
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 297
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 298
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 299
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 300
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 309
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 309
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 312
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 312
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 315
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 315
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 318
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 318
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 321
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 321
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 396
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 397
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 398
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 399
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 400
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 409
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 409
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 412
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 412
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 415
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 415
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 418
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 418
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 421
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 421
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 600
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 601
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 602
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 603
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 604
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 613
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 613
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 616
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 616
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 619
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 619
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 622
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 622
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 625
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 625
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 700
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 701
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 702
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 703
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 704
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 713
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 713
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 716
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 716
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 719
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 719
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 722
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 722
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 725
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 725
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 905
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 906
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 907
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 908
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 909
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 918
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 918
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 921
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 921
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 924
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 924
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 927
ERROR - 2020-01-29 11:35:46 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 927
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 930
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 930
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1005
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1006
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1007
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1008
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1009
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1018
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1018
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1021
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1021
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1024
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1024
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1027
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1027
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1030
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1030
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1211
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1212
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1213
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1214
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1215
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1224
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1224
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1227
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1227
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1230
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1230
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1233
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1233
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1236
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1236
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1311
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1312
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1313
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1314
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1315
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1324
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1324
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1327
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1327
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1330
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1330
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1333
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1333
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1336
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1336
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1488
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1491
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1494
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1497
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1500
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1503
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1506
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1509
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1616
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1619
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1622
ERROR - 2020-01-29 11:35:47 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1625
ERROR - 2020-01-29 11:38:03 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 11:38:04 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 81
ERROR - 2020-01-29 11:38:04 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 81
ERROR - 2020-01-29 11:39:29 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 11:39:29 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 81
ERROR - 2020-01-29 11:39:29 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 81
ERROR - 2020-01-29 11:40:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 11:40:17 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 81
ERROR - 2020-01-29 11:40:17 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 81
ERROR - 2020-01-29 11:43:25 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 11:43:25 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 81
ERROR - 2020-01-29 11:43:25 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 81
ERROR - 2020-01-29 11:48:31 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 11:48:48 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 11:48:51 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 294
ERROR - 2020-01-29 11:48:54 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 399
ERROR - 2020-01-29 11:48:55 --> Query error: Duplicate entry '0-0' for key 'PRIMARY' - Invalid query: INSERT INTO `xls_import_job_placement` (`beneficiary_id`, `placement_type`, `sme_or_cpmpany_id`, `wage`, `consortium`, `EmploymentDate`, `End_Date`, `status`, `postdate`, `file_name`) VALUES ('0', 'Employment', '', '0', '', '1970-01-01', '1970-01-01', 1, '2020-01-29', 'Lot1_Jan202020_055745PM_newone.xlsx')
ERROR - 2020-01-29 11:48:55 --> Query error: Duplicate entry '0-0' for key 'PRIMARY' - Invalid query: INSERT INTO `xls_import_job_placement` (`beneficiary_id`, `placement_type`, `sme_or_cpmpany_id`, `wage`, `consortium`, `EmploymentDate`, `End_Date`, `status`, `postdate`, `file_name`) VALUES ('0', '', '', '0', '', '1970-01-01', '1970-01-01', 1, '2020-01-29', 'Lot1_Jan202020_055745PM_newone.xlsx')
ERROR - 2020-01-29 11:48:55 --> Query error: Duplicate entry '0-0' for key 'PRIMARY' - Invalid query: INSERT INTO `xls_import_job_placement` (`beneficiary_id`, `placement_type`, `sme_or_cpmpany_id`, `wage`, `consortium`, `EmploymentDate`, `End_Date`, `status`, `postdate`, `file_name`) VALUES ('0', '', '', '0', '', '2019-12-01', '2019-09-29', 1, '2020-01-29', 'Lot1_Jan202020_055745PM_newone.xlsx')
ERROR - 2020-01-29 11:48:55 --> Query error: Duplicate entry '0-0' for key 'PRIMARY' - Invalid query: INSERT INTO `xls_import_job_placement` (`beneficiary_id`, `placement_type`, `sme_or_cpmpany_id`, `wage`, `consortium`, `EmploymentDate`, `End_Date`, `status`, `postdate`, `file_name`) VALUES ('0', 'Employment', '', '0', '', '1970-01-01', '1970-01-01', 1, '2020-01-29', 'Lot1_Jan202020_055745PM_newone.xlsx')
ERROR - 2020-01-29 11:48:55 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 594
ERROR - 2020-01-29 11:48:55 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 693
ERROR - 2020-01-29 11:48:55 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 787
ERROR - 2020-01-29 11:48:55 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 882
ERROR - 2020-01-29 11:48:55 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 978
ERROR - 2020-01-29 11:48:55 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 1079
ERROR - 2020-01-29 11:48:55 --> Query error: Column count doesn't match value count at row 1 - Invalid query: INSERT xls_import_tvet_training SELECT *,CURRENT_TIMESTAMP() FROM xls_import_tvet_training_bkp
ERROR - 2020-01-29 11:48:56 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 1182
ERROR - 2020-01-29 11:48:56 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 11:50:53 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 11:50:56 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 294
ERROR - 2020-01-29 11:50:58 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 399
ERROR - 2020-01-29 11:51:00 --> Query error: Duplicate entry '0-0' for key 'PRIMARY' - Invalid query: INSERT INTO `xls_import_job_placement` (`beneficiary_id`, `placement_type`, `sme_or_cpmpany_id`, `wage`, `consortium`, `EmploymentDate`, `End_Date`, `status`, `postdate`, `file_name`) VALUES ('0', 'Employment', '', '0', '', '1970-01-01', '1970-01-01', 1, '2020-01-29', 'Lot1_Jan202020_055745PM_newone.xlsx')
ERROR - 2020-01-29 11:51:00 --> Query error: Duplicate entry '0-0' for key 'PRIMARY' - Invalid query: INSERT INTO `xls_import_job_placement` (`beneficiary_id`, `placement_type`, `sme_or_cpmpany_id`, `wage`, `consortium`, `EmploymentDate`, `End_Date`, `status`, `postdate`, `file_name`) VALUES ('0', '', '', '0', '', '1970-01-01', '1970-01-01', 1, '2020-01-29', 'Lot1_Jan202020_055745PM_newone.xlsx')
ERROR - 2020-01-29 11:51:00 --> Query error: Duplicate entry '0-0' for key 'PRIMARY' - Invalid query: INSERT INTO `xls_import_job_placement` (`beneficiary_id`, `placement_type`, `sme_or_cpmpany_id`, `wage`, `consortium`, `EmploymentDate`, `End_Date`, `status`, `postdate`, `file_name`) VALUES ('0', '', '', '0', '', '2019-12-01', '2019-09-29', 1, '2020-01-29', 'Lot1_Jan202020_055745PM_newone.xlsx')
ERROR - 2020-01-29 11:51:00 --> Query error: Duplicate entry '0-0' for key 'PRIMARY' - Invalid query: INSERT INTO `xls_import_job_placement` (`beneficiary_id`, `placement_type`, `sme_or_cpmpany_id`, `wage`, `consortium`, `EmploymentDate`, `End_Date`, `status`, `postdate`, `file_name`) VALUES ('0', 'Employment', '', '0', '', '1970-01-01', '1970-01-01', 1, '2020-01-29', 'Lot1_Jan202020_055745PM_newone.xlsx')
ERROR - 2020-01-29 11:51:00 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 594
ERROR - 2020-01-29 11:51:00 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 693
ERROR - 2020-01-29 11:51:00 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 787
ERROR - 2020-01-29 11:51:00 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 882
ERROR - 2020-01-29 11:51:00 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 978
ERROR - 2020-01-29 11:51:01 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 1079
ERROR - 2020-01-29 11:51:01 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\since\application\modules\importdb\controllers\Importdb.php 1182
ERROR - 2020-01-29 11:51:01 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 12:22:45 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 12:22:45 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 81
ERROR - 2020-01-29 12:22:45 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 81
ERROR - 2020-01-29 12:22:48 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 12:22:48 --> Severity: Notice --> Undefined variable: where1 C:\danxampp\htdocs\since\application\modules\reports\controllers\Reports.php 117
ERROR - 2020-01-29 12:22:51 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 12:22:51 --> Severity: Notice --> Undefined variable: where1 C:\danxampp\htdocs\since\application\modules\reports\controllers\Reports.php 117
ERROR - 2020-01-29 12:23:00 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 12:23:01 --> Severity: Notice --> Undefined variable: where1 C:\danxampp\htdocs\since\application\modules\reports\controllers\Reports.php 117
ERROR - 2020-01-29 12:41:48 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 12:41:48 --> Severity: Notice --> Undefined variable: where1 C:\danxampp\htdocs\since\application\modules\reports\controllers\Reports.php 117
ERROR - 2020-01-29 12:41:48 --> Severity: error --> Exception: syntax error, unexpected end of file C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 212
ERROR - 2020-01-29 12:42:19 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 12:42:19 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 81
ERROR - 2020-01-29 12:42:19 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 81
ERROR - 2020-01-29 12:42:19 --> Query error: Unknown column 'consortium' in 'where clause' - Invalid query: SELECT distinct count(training_name),training_type,region FROM xls_import_tvet_training where training_type='New' and consortium='Lot1'  GROUP by consortium,valuechain
ERROR - 2020-01-29 12:43:04 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 12:43:04 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 81
ERROR - 2020-01-29 12:43:04 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 81
ERROR - 2020-01-29 12:43:47 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 12:43:47 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 81
ERROR - 2020-01-29 12:43:47 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 81
ERROR - 2020-01-29 12:44:14 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 12:44:14 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 81
ERROR - 2020-01-29 12:44:14 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 81
ERROR - 2020-01-29 12:45:46 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 12:45:46 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 81
ERROR - 2020-01-29 12:45:46 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 81
ERROR - 2020-01-29 13:15:27 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 13:15:27 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 81
ERROR - 2020-01-29 13:15:27 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 81
ERROR - 2020-01-29 13:15:27 --> Query error: Reference 'valuechain' not supported (forward reference in item list) - Invalid query: select (SELECT distinct count(training_name) as NewTraining FROM xls_import_tvet_training where training_type='New' and valuechain=t2.valuechain and  consortium=t2.consortium GROUP by consortium,valuechain) as A, 
            (SELECT distinct count(training_name) as NewTraining FROM xls_import_tvet_training where training_type='Improved' and valuechain=t2.valuechain and consortium=t2.consortium GROUP by consortium,valuechain) as B,t2.valuechain
ERROR - 2020-01-29 13:17:48 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 13:17:48 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 81
ERROR - 2020-01-29 13:17:48 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 81
ERROR - 2020-01-29 13:17:48 --> Query error: Unknown column 't2.valuechain' in 'where clause' - Invalid query: select (SELECT distinct count(training_name) as NewTraining FROM xls_import_tvet_training where training_type='New' and valuechain=t2.valuechain and  consortium=t2.consortium GROUP by consortium,valuechain) as A, 
            (SELECT distinct count(training_name) as NewTraining FROM xls_import_tvet_training where training_type='Improved' and valuechain=t2.valuechain and consortium=t2.consortium GROUP by consortium,valuechain) as B from xls_import_tvet_training GROUP by t2.consortium,t2.valuechain
ERROR - 2020-01-29 13:17:58 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 13:17:58 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 81
ERROR - 2020-01-29 13:17:58 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 81
ERROR - 2020-01-29 13:19:49 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 13:19:49 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 81
ERROR - 2020-01-29 13:19:49 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 81
ERROR - 2020-01-29 13:20:29 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 13:20:29 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 81
ERROR - 2020-01-29 13:20:29 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 81
ERROR - 2020-01-29 13:24:21 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 13:24:21 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 81
ERROR - 2020-01-29 13:24:21 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 81
ERROR - 2020-01-29 13:25:42 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 13:25:42 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 74
ERROR - 2020-01-29 13:25:42 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 74
ERROR - 2020-01-29 13:26:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 13:26:43 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 74
ERROR - 2020-01-29 13:26:43 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 74
ERROR - 2020-01-29 13:27:00 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 13:27:00 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 74
ERROR - 2020-01-29 13:27:00 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 74
ERROR - 2020-01-29 13:27:28 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 13:27:28 --> Severity: Notice --> Undefined variable: where1 C:\danxampp\htdocs\since\application\modules\reports\controllers\Reports.php 117
ERROR - 2020-01-29 13:27:32 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 13:27:32 --> Severity: Notice --> Undefined variable: where1 C:\danxampp\htdocs\since\application\modules\reports\controllers\Reports.php 117
ERROR - 2020-01-29 13:28:13 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 13:28:13 --> Severity: Notice --> Undefined variable: where1 C:\danxampp\htdocs\since\application\modules\reports\controllers\Reports.php 117
ERROR - 2020-01-29 13:28:16 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 13:28:16 --> Severity: Notice --> Undefined variable: where1 C:\danxampp\htdocs\since\application\modules\reports\controllers\Reports.php 117
ERROR - 2020-01-29 13:28:18 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 13:28:18 --> Severity: Notice --> Undefined variable: where1 C:\danxampp\htdocs\since\application\modules\reports\controllers\Reports.php 117
ERROR - 2020-01-29 13:28:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 13:28:44 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 13:28:44 --> Severity: Notice --> Undefined variable: where1 C:\danxampp\htdocs\since\application\modules\reports\controllers\Reports.php 117
ERROR - 2020-01-29 13:29:20 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 13:29:20 --> Severity: Notice --> Undefined variable: where1 C:\danxampp\htdocs\since\application\modules\reports\controllers\Reports.php 117
ERROR - 2020-01-29 13:29:24 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 13:29:24 --> Severity: Notice --> Undefined variable: where1 C:\danxampp\htdocs\since\application\modules\reports\controllers\Reports.php 117
ERROR - 2020-01-29 13:30:31 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 13:30:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 13:30:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 13:30:49 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 13:30:57 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 13:31:40 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 13:31:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 13:31:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 13:32:38 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 13:32:49 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 13:32:57 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 13:33:12 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 13:33:12 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 74
ERROR - 2020-01-29 13:33:12 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 74
ERROR - 2020-01-29 14:18:58 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:19:25 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:19:29 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:19:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:20:32 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:20:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:21:06 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:21:06 --> Severity: Notice --> Undefined variable: where1 C:\danxampp\htdocs\since\application\modules\reports\controllers\Reports.php 118
ERROR - 2020-01-29 14:21:46 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:21:46 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 74
ERROR - 2020-01-29 14:21:46 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 74
ERROR - 2020-01-29 14:21:58 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:22:10 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:22:10 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 74
ERROR - 2020-01-29 14:22:10 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 74
ERROR - 2020-01-29 14:22:15 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:22:31 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:22:45 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:22:45 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 74
ERROR - 2020-01-29 14:22:45 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 74
ERROR - 2020-01-29 14:22:49 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:23:22 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:23:22 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 74
ERROR - 2020-01-29 14:23:22 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 74
ERROR - 2020-01-29 14:23:25 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:24:19 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:24:19 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 74
ERROR - 2020-01-29 14:24:19 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 74
ERROR - 2020-01-29 14:24:25 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:24:28 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:25:26 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:26:37 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:26:37 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 74
ERROR - 2020-01-29 14:26:37 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 74
ERROR - 2020-01-29 14:28:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:28:43 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 74
ERROR - 2020-01-29 14:28:43 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 74
ERROR - 2020-01-29 14:28:52 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:28:55 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:29:06 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:29:06 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 74
ERROR - 2020-01-29 14:29:06 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 74
ERROR - 2020-01-29 14:29:16 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:29:21 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:29:26 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:30:01 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:30:01 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 74
ERROR - 2020-01-29 14:30:01 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 74
ERROR - 2020-01-29 14:30:10 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:30:10 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 74
ERROR - 2020-01-29 14:30:10 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 74
ERROR - 2020-01-29 14:30:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:30:39 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 77
ERROR - 2020-01-29 14:30:39 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 77
ERROR - 2020-01-29 14:35:52 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:35:52 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 77
ERROR - 2020-01-29 14:35:52 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 77
ERROR - 2020-01-29 14:35:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:36:02 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:36:12 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:36:12 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 77
ERROR - 2020-01-29 14:36:12 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 77
ERROR - 2020-01-29 14:36:14 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:36:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:39:37 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:39:50 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:39:53 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:40:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:40:08 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 77
ERROR - 2020-01-29 14:40:08 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 77
ERROR - 2020-01-29 14:45:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:45:33 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 77
ERROR - 2020-01-29 14:45:33 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 77
ERROR - 2020-01-29 14:45:33 --> Severity: Notice --> Undefined variable: jk C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 172
ERROR - 2020-01-29 14:45:33 --> Severity: Notice --> Undefined index:  C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 172
ERROR - 2020-01-29 14:45:33 --> Severity: Notice --> Undefined variable: jk C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 172
ERROR - 2020-01-29 14:45:33 --> Severity: Notice --> Undefined index:  C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 172
ERROR - 2020-01-29 14:45:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:45:59 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 77
ERROR - 2020-01-29 14:45:59 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 77
ERROR - 2020-01-29 14:45:59 --> Severity: Notice --> Undefined variable: jk C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 172
ERROR - 2020-01-29 14:45:59 --> Severity: Notice --> Undefined index:  C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 172
ERROR - 2020-01-29 14:45:59 --> Severity: Notice --> Undefined variable: jk C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 172
ERROR - 2020-01-29 14:45:59 --> Severity: Notice --> Undefined index:  C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 172
ERROR - 2020-01-29 14:47:06 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:47:06 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 77
ERROR - 2020-01-29 14:47:06 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 77
ERROR - 2020-01-29 14:47:06 --> Severity: Notice --> Undefined offset: 1 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 187
ERROR - 2020-01-29 14:47:06 --> Severity: Notice --> Undefined offset: 2 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 187
ERROR - 2020-01-29 14:47:06 --> Severity: Notice --> Undefined offset: 3 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 187
ERROR - 2020-01-29 14:47:06 --> Severity: Notice --> Undefined offset: 4 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 187
ERROR - 2020-01-29 14:47:50 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:47:50 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 77
ERROR - 2020-01-29 14:47:50 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 77
ERROR - 2020-01-29 14:47:50 --> Severity: Notice --> Undefined offset: 1 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 187
ERROR - 2020-01-29 14:47:50 --> Severity: Notice --> Undefined offset: 2 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 187
ERROR - 2020-01-29 14:47:50 --> Severity: Notice --> Undefined offset: 3 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 187
ERROR - 2020-01-29 14:47:50 --> Severity: Notice --> Undefined offset: 4 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 187
ERROR - 2020-01-29 14:48:06 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:48:06 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 77
ERROR - 2020-01-29 14:48:06 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 77
ERROR - 2020-01-29 14:48:06 --> Severity: Notice --> Undefined offset: 1 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 188
ERROR - 2020-01-29 14:48:06 --> Severity: Notice --> Undefined offset: 2 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 188
ERROR - 2020-01-29 14:48:06 --> Severity: Notice --> Undefined offset: 3 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 188
ERROR - 2020-01-29 14:48:06 --> Severity: Notice --> Undefined offset: 4 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 188
ERROR - 2020-01-29 14:48:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:48:43 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 77
ERROR - 2020-01-29 14:48:43 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 77
ERROR - 2020-01-29 14:48:43 --> Severity: Notice --> Undefined offset: 1 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 188
ERROR - 2020-01-29 14:48:43 --> Severity: Notice --> Undefined offset: 2 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 188
ERROR - 2020-01-29 14:48:43 --> Severity: Notice --> Undefined offset: 3 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 188
ERROR - 2020-01-29 14:49:02 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:49:02 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 77
ERROR - 2020-01-29 14:49:02 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 77
ERROR - 2020-01-29 14:49:02 --> Severity: Notice --> Undefined offset: 1 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 188
ERROR - 2020-01-29 14:49:02 --> Severity: Notice --> Undefined offset: 2 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 188
ERROR - 2020-01-29 14:49:02 --> Severity: Notice --> Undefined offset: 3 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 188
ERROR - 2020-01-29 14:50:01 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:50:01 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 77
ERROR - 2020-01-29 14:50:01 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 77
ERROR - 2020-01-29 14:50:01 --> Severity: Notice --> Undefined offset: 1 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 188
ERROR - 2020-01-29 14:50:01 --> Severity: Notice --> Undefined offset: 1 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 190
ERROR - 2020-01-29 14:50:01 --> Severity: Notice --> Undefined offset: 2 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 188
ERROR - 2020-01-29 14:50:01 --> Severity: Notice --> Undefined offset: 2 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 190
ERROR - 2020-01-29 14:50:01 --> Severity: Notice --> Undefined offset: 3 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 188
ERROR - 2020-01-29 14:50:01 --> Severity: Notice --> Undefined offset: 3 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 190
ERROR - 2020-01-29 14:50:44 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:50:44 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 77
ERROR - 2020-01-29 14:50:44 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 77
ERROR - 2020-01-29 14:50:44 --> Severity: Notice --> Undefined offset: 1 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 189
ERROR - 2020-01-29 14:50:44 --> Severity: Notice --> Undefined offset: 2 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 189
ERROR - 2020-01-29 14:50:44 --> Severity: Notice --> Undefined offset: 3 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 189
ERROR - 2020-01-29 14:51:19 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:51:19 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 77
ERROR - 2020-01-29 14:51:19 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 77
ERROR - 2020-01-29 14:51:19 --> Severity: Notice --> Undefined offset: 1 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 189
ERROR - 2020-01-29 14:51:19 --> Severity: Notice --> Undefined offset: 1 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 191
ERROR - 2020-01-29 14:51:19 --> Severity: Notice --> Undefined offset: 2 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 189
ERROR - 2020-01-29 14:51:19 --> Severity: Notice --> Undefined offset: 2 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 191
ERROR - 2020-01-29 14:51:19 --> Severity: Notice --> Undefined offset: 3 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 189
ERROR - 2020-01-29 14:51:19 --> Severity: Notice --> Undefined offset: 3 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 191
ERROR - 2020-01-29 14:51:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:51:33 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 77
ERROR - 2020-01-29 14:51:34 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 77
ERROR - 2020-01-29 14:51:34 --> Severity: Notice --> Undefined offset: 1 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 189
ERROR - 2020-01-29 14:51:34 --> Severity: Notice --> Undefined offset: 1 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 191
ERROR - 2020-01-29 14:51:34 --> Severity: Notice --> Undefined offset: 2 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 189
ERROR - 2020-01-29 14:51:34 --> Severity: Notice --> Undefined offset: 2 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 191
ERROR - 2020-01-29 14:51:34 --> Severity: Notice --> Undefined offset: 3 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 189
ERROR - 2020-01-29 14:51:34 --> Severity: Notice --> Undefined offset: 3 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 191
ERROR - 2020-01-29 14:54:05 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:54:05 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 77
ERROR - 2020-01-29 14:54:05 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 77
ERROR - 2020-01-29 14:54:05 --> Severity: Notice --> Undefined offset: 1 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 189
ERROR - 2020-01-29 14:54:05 --> Severity: Notice --> Undefined offset: 1 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 191
ERROR - 2020-01-29 14:54:05 --> Severity: Notice --> Undefined offset: 2 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 189
ERROR - 2020-01-29 14:54:05 --> Severity: Notice --> Undefined offset: 2 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 191
ERROR - 2020-01-29 14:54:05 --> Severity: Notice --> Undefined offset: 3 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 189
ERROR - 2020-01-29 14:54:05 --> Severity: Notice --> Undefined offset: 3 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 191
ERROR - 2020-01-29 14:54:48 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:54:48 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 77
ERROR - 2020-01-29 14:54:48 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 77
ERROR - 2020-01-29 14:54:48 --> Severity: Notice --> Undefined offset: 1 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 189
ERROR - 2020-01-29 14:54:48 --> Severity: Notice --> Undefined offset: 2 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 189
ERROR - 2020-01-29 14:54:48 --> Severity: Notice --> Undefined offset: 1 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 191
ERROR - 2020-01-29 14:54:48 --> Severity: Notice --> Undefined offset: 2 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 191
ERROR - 2020-01-29 14:54:48 --> Severity: Notice --> Undefined offset: 2 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 189
ERROR - 2020-01-29 14:54:48 --> Severity: Notice --> Undefined offset: 3 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 189
ERROR - 2020-01-29 14:54:48 --> Severity: Notice --> Undefined offset: 2 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 191
ERROR - 2020-01-29 14:54:48 --> Severity: Notice --> Undefined offset: 3 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 191
ERROR - 2020-01-29 14:54:48 --> Severity: Notice --> Undefined offset: 3 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 189
ERROR - 2020-01-29 14:54:48 --> Severity: Notice --> Undefined offset: 4 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 189
ERROR - 2020-01-29 14:54:48 --> Severity: Notice --> Undefined offset: 3 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 191
ERROR - 2020-01-29 14:54:48 --> Severity: Notice --> Undefined offset: 4 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 191
ERROR - 2020-01-29 14:56:04 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:56:04 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 77
ERROR - 2020-01-29 14:56:04 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 77
ERROR - 2020-01-29 14:56:04 --> Severity: Notice --> Undefined offset: 2 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 192
ERROR - 2020-01-29 14:56:04 --> Severity: Notice --> Undefined offset: 2 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 192
ERROR - 2020-01-29 14:56:04 --> Severity: Notice --> Undefined offset: 3 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 192
ERROR - 2020-01-29 14:57:00 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:57:00 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 77
ERROR - 2020-01-29 14:57:00 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 77
ERROR - 2020-01-29 14:57:00 --> Severity: Notice --> Undefined offset: 1 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 192
ERROR - 2020-01-29 14:57:00 --> Severity: Notice --> Undefined offset: 1 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 190
ERROR - 2020-01-29 14:57:00 --> Severity: Notice --> Undefined offset: 1 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 192
ERROR - 2020-01-29 14:57:00 --> Severity: Notice --> Undefined offset: 2 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 192
ERROR - 2020-01-29 14:57:00 --> Severity: Notice --> Undefined offset: 2 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 190
ERROR - 2020-01-29 14:57:00 --> Severity: Notice --> Undefined offset: 2 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 192
ERROR - 2020-01-29 14:57:00 --> Severity: Notice --> Undefined offset: 3 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 192
ERROR - 2020-01-29 14:57:00 --> Severity: Notice --> Undefined offset: 1 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 192
ERROR - 2020-01-29 14:57:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:57:30 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 77
ERROR - 2020-01-29 14:57:30 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 77
ERROR - 2020-01-29 14:57:30 --> Severity: Notice --> Undefined offset: 1 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 192
ERROR - 2020-01-29 14:57:30 --> Severity: Notice --> Undefined offset: 2 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 192
ERROR - 2020-01-29 14:57:30 --> Severity: Notice --> Undefined offset: 3 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 192
ERROR - 2020-01-29 14:57:36 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:57:36 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 77
ERROR - 2020-01-29 14:57:36 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 77
ERROR - 2020-01-29 14:57:36 --> Severity: Notice --> Undefined offset: 1 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 192
ERROR - 2020-01-29 14:57:36 --> Severity: Notice --> Undefined offset: 1 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 190
ERROR - 2020-01-29 14:57:36 --> Severity: Notice --> Undefined offset: 1 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 192
ERROR - 2020-01-29 14:57:36 --> Severity: Notice --> Undefined offset: 2 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 192
ERROR - 2020-01-29 14:57:36 --> Severity: Notice --> Undefined offset: 2 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 190
ERROR - 2020-01-29 14:57:36 --> Severity: Notice --> Undefined offset: 2 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 192
ERROR - 2020-01-29 14:57:36 --> Severity: Notice --> Undefined offset: 3 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 192
ERROR - 2020-01-29 14:57:36 --> Severity: Notice --> Undefined offset: 1 C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 192
ERROR - 2020-01-29 14:58:03 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:58:03 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 77
ERROR - 2020-01-29 14:58:03 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 77
ERROR - 2020-01-29 14:59:02 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:59:03 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 77
ERROR - 2020-01-29 14:59:03 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 77
ERROR - 2020-01-29 14:59:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 14:59:34 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 122
ERROR - 2020-01-29 14:59:34 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 122
ERROR - 2020-01-29 18:33:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 18:33:44 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 18:33:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 18:33:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 18:34:01 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 100
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 100
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 296
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 297
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 298
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 299
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 300
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 309
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 309
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 312
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 312
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 315
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 315
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 318
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 318
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 321
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 321
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 396
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 397
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 398
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 399
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 400
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 409
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 409
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 412
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 412
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 415
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 415
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 418
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 418
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 421
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 421
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined variable: totalrowsum C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 428
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 296
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 297
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 298
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 299
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 300
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 309
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 309
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 312
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 312
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 315
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 315
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 318
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 318
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 321
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 321
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 396
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 397
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 398
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 399
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 400
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 409
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 409
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 412
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 412
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 415
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 415
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 418
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 418
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 421
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 421
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 600
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 601
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 602
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 603
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 604
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 613
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 613
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 616
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 616
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 619
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 619
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 622
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 622
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 625
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 625
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 700
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 701
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 702
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 703
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 704
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 713
ERROR - 2020-01-29 18:34:02 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 713
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 716
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 716
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 719
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 719
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 722
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 722
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 725
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 725
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 600
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 601
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 602
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 603
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 604
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 613
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 613
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 616
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 616
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 619
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 619
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 622
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 622
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 625
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 625
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 700
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 701
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 702
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 703
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 704
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 713
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 713
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 716
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 716
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 719
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 719
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 722
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 722
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 725
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 725
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 905
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 906
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 907
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 908
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 909
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 918
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 918
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 921
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 921
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 924
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 924
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 927
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 927
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 930
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 930
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1005
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1006
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1007
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1008
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1009
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1018
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1018
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1021
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1021
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1024
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1024
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1027
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1027
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1030
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1030
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 905
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 906
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 907
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 908
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 909
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 918
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 918
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 921
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 921
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 924
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 924
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 927
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 927
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 930
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 930
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1005
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1006
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1007
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1008
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1009
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1018
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1018
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1021
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1021
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1024
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1024
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1027
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1027
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1030
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1030
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1211
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1212
ERROR - 2020-01-29 18:34:03 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1213
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1214
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1215
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1224
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1224
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1227
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1227
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1230
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1230
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1233
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1233
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1236
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1236
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1311
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1312
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1313
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1314
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1315
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1324
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1324
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1327
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1327
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1330
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1330
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1333
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1333
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1336
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1336
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1211
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1212
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1213
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1214
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1215
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1224
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1224
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1227
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1227
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1230
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1230
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1233
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1233
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1236
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1236
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1311
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1312
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1313
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1314
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1315
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1324
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1324
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1327
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1327
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1330
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1330
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1333
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1333
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1336
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1336
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1488
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1491
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1494
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1497
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1500
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1503
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1506
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1509
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1488
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1491
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1494
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1497
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1500
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1503
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1506
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1509
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1616
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1619
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1622
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1625
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1616
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1619
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1622
ERROR - 2020-01-29 18:34:04 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1625
ERROR - 2020-01-29 18:34:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 18:34:08 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 296
ERROR - 2020-01-29 18:34:08 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 297
ERROR - 2020-01-29 18:34:08 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 298
ERROR - 2020-01-29 18:34:08 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 299
ERROR - 2020-01-29 18:34:08 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 300
ERROR - 2020-01-29 18:34:08 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 309
ERROR - 2020-01-29 18:34:08 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 309
ERROR - 2020-01-29 18:34:08 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 312
ERROR - 2020-01-29 18:34:08 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 312
ERROR - 2020-01-29 18:34:08 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 315
ERROR - 2020-01-29 18:34:08 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 315
ERROR - 2020-01-29 18:34:08 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 318
ERROR - 2020-01-29 18:34:08 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 318
ERROR - 2020-01-29 18:34:08 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 321
ERROR - 2020-01-29 18:34:08 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 321
ERROR - 2020-01-29 18:34:08 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 396
ERROR - 2020-01-29 18:34:08 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 397
ERROR - 2020-01-29 18:34:08 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 398
ERROR - 2020-01-29 18:34:08 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 399
ERROR - 2020-01-29 18:34:08 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 400
ERROR - 2020-01-29 18:34:08 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 409
ERROR - 2020-01-29 18:34:08 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 409
ERROR - 2020-01-29 18:34:08 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 412
ERROR - 2020-01-29 18:34:08 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 412
ERROR - 2020-01-29 18:34:08 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 415
ERROR - 2020-01-29 18:34:08 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 415
ERROR - 2020-01-29 18:34:08 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 418
ERROR - 2020-01-29 18:34:08 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 418
ERROR - 2020-01-29 18:34:08 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 421
ERROR - 2020-01-29 18:34:08 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 421
ERROR - 2020-01-29 18:34:08 --> Severity: Notice --> Undefined variable: totalrowsum C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 428
ERROR - 2020-01-29 18:34:08 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 600
ERROR - 2020-01-29 18:34:08 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 601
ERROR - 2020-01-29 18:34:08 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 602
ERROR - 2020-01-29 18:34:08 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 603
ERROR - 2020-01-29 18:34:08 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 604
ERROR - 2020-01-29 18:34:08 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 613
ERROR - 2020-01-29 18:34:08 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 613
ERROR - 2020-01-29 18:34:08 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 616
ERROR - 2020-01-29 18:34:08 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 616
ERROR - 2020-01-29 18:34:08 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 619
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 619
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 622
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 622
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 625
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 625
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 700
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 701
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 702
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 703
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 704
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 713
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 713
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 716
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 716
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 719
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 719
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 722
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 722
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 725
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 725
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 905
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 906
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 907
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 908
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 909
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 918
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 918
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 921
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 921
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 924
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 924
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 927
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 927
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 930
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 930
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1005
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1006
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1007
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1008
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1009
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1018
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1018
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1021
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1021
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1024
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1024
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1027
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1027
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1030
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1030
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1211
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1212
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1213
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1214
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1215
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1224
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1224
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1227
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1227
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1230
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1230
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1233
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1233
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1236
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1236
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1311
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1312
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1313
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1314
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1315
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1324
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1324
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1327
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1327
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1330
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1330
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1333
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1333
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1336
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1336
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1488
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1491
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1494
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1497
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1500
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1503
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1506
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1509
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1616
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1619
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1622
ERROR - 2020-01-29 18:34:09 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1625
ERROR - 2020-01-29 18:34:14 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 296
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 297
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 298
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 299
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 300
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 309
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 309
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 312
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 312
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 315
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 315
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 318
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 318
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 321
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 321
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 396
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 397
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 398
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 399
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 400
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 409
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 409
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 412
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 412
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 415
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 415
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 418
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 418
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 421
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 421
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined variable: totalrowsum C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 428
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 600
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 601
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 602
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 603
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 604
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 613
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 613
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 616
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 616
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 619
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 619
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 622
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 622
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 625
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 625
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 700
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 701
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 702
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 703
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 704
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 713
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 713
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 716
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 716
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 719
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 719
ERROR - 2020-01-29 18:34:14 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 722
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 722
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 725
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 725
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 905
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 906
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 907
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 908
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 909
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 918
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 918
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 921
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 921
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 924
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 924
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 927
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 927
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 930
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 930
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1005
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1006
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1007
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1008
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1009
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1018
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1018
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1021
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1021
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1024
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1024
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1027
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1027
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1030
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1030
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1211
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1212
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1213
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1214
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1215
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1224
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1224
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1227
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1227
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1230
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1230
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1233
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1233
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1236
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1236
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1311
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1312
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1313
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1314
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1315
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1324
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1324
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1327
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1327
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1330
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1330
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1333
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1333
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1336
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1336
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1488
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1491
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1494
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1497
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1500
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1503
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1506
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1509
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1616
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1619
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1622
ERROR - 2020-01-29 18:34:15 --> Severity: Notice --> Undefined offset: 0 C:\danxampp\htdocs\since\application\modules\reports\views\overall_objective_report.php 1625
ERROR - 2020-01-29 18:34:24 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 18:34:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 18:34:33 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 122
ERROR - 2020-01-29 18:34:33 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 122
ERROR - 2020-01-29 18:37:22 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 18:37:24 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 18:42:21 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 18:43:04 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 18:43:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 18:47:46 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 18:47:46 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 122
ERROR - 2020-01-29 18:47:46 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 122
ERROR - 2020-01-29 18:47:46 --> Severity: Notice --> Undefined variable: todate C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 226
ERROR - 2020-01-29 18:47:46 --> Severity: Notice --> Undefined variable: todate C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 226
ERROR - 2020-01-29 18:47:56 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 18:47:57 --> Severity: Notice --> Undefined variable: todate C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 226
ERROR - 2020-01-29 18:47:57 --> Severity: Notice --> Undefined variable: todate C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 226
ERROR - 2020-01-29 18:51:52 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 18:51:52 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 131
ERROR - 2020-01-29 18:51:52 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 131
ERROR - 2020-01-29 18:52:07 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 18:52:07 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 131
ERROR - 2020-01-29 18:52:07 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 131
ERROR - 2020-01-29 18:52:47 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 18:52:47 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 131
ERROR - 2020-01-29 18:52:47 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 131
ERROR - 2020-01-29 18:53:55 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 18:53:55 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 131
ERROR - 2020-01-29 18:53:55 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 131
ERROR - 2020-01-29 18:54:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 18:55:15 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 18:55:15 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 134
ERROR - 2020-01-29 18:55:15 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 134
ERROR - 2020-01-29 18:55:25 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 18:55:25 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 134
ERROR - 2020-01-29 18:55:25 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 134
ERROR - 2020-01-29 18:55:40 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 18:55:40 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 134
ERROR - 2020-01-29 18:55:40 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 134
ERROR - 2020-01-29 18:55:47 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 18:55:47 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 134
ERROR - 2020-01-29 18:55:47 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 134
ERROR - 2020-01-29 18:56:14 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 18:56:14 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 134
ERROR - 2020-01-29 18:56:14 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 134
ERROR - 2020-01-29 18:56:19 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 18:56:19 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 134
ERROR - 2020-01-29 18:56:19 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 134
ERROR - 2020-01-29 18:56:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 18:56:35 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 134
ERROR - 2020-01-29 18:56:35 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 134
ERROR - 2020-01-29 18:57:11 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 18:57:11 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 134
ERROR - 2020-01-29 18:57:11 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 134
ERROR - 2020-01-29 18:57:19 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 18:57:19 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 134
ERROR - 2020-01-29 18:57:19 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 134
ERROR - 2020-01-29 18:57:49 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 18:58:07 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 18:58:25 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 18:58:27 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 18:58:53 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 18:59:02 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 18:59:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 19:00:52 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 19:00:54 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 19:00:54 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 19:00:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 19:01:00 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 19:01:00 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 19:01:03 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 19:01:11 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 19:01:25 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 19:01:53 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 19:02:23 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 19:02:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 19:02:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 19:03:16 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 19:03:28 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 19:03:37 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 19:03:37 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 134
ERROR - 2020-01-29 19:03:37 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 134
ERROR - 2020-01-29 19:03:49 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 19:03:49 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 134
ERROR - 2020-01-29 19:03:49 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 134
ERROR - 2020-01-29 19:04:00 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 19:04:19 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 19:04:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 19:04:33 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 134
ERROR - 2020-01-29 19:04:33 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 134
ERROR - 2020-01-29 19:04:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 19:04:43 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 134
ERROR - 2020-01-29 19:04:43 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 134
ERROR - 2020-01-29 19:04:46 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 19:04:58 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 19:04:58 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 134
ERROR - 2020-01-29 19:04:58 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 134
ERROR - 2020-01-29 19:05:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 19:05:08 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 134
ERROR - 2020-01-29 19:05:08 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 134
ERROR - 2020-01-29 19:05:24 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 19:05:24 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 134
ERROR - 2020-01-29 19:05:24 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 134
ERROR - 2020-01-29 19:07:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 19:07:42 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 134
ERROR - 2020-01-29 19:07:42 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 134
ERROR - 2020-01-29 19:08:03 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 19:08:03 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 134
ERROR - 2020-01-29 19:08:03 --> Severity: Notice --> Undefined index: consortium C:\danxampp\htdocs\since\application\modules\reports\views\expected_outcome1_report.php 134
ERROR - 2020-01-29 19:08:15 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 19:08:19 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 19:23:00 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-29 19:26:00 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
