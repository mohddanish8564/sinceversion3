<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-21 11:50:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 11:50:46 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 11:50:46 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 11:51:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 11:51:45 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 11:51:45 --> 404 Page Not Found: /index
ERROR - 2020-01-21 11:51:47 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 11:51:47 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 11:51:50 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 11:51:55 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 11:51:55 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 11:52:00 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 11:52:00 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 11:52:00 --> 404 Page Not Found: /index
ERROR - 2020-01-21 12:00:37 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:00:37 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:00:37 --> 404 Page Not Found: /index
ERROR - 2020-01-21 12:00:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:00:40 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:00:40 --> 404 Page Not Found: /index
ERROR - 2020-01-21 12:01:09 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:01:09 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:01:09 --> 404 Page Not Found: /index
ERROR - 2020-01-21 12:02:29 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:02:29 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:02:30 --> 404 Page Not Found: /index
ERROR - 2020-01-21 12:02:57 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:02:57 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:02:57 --> 404 Page Not Found: /index
ERROR - 2020-01-21 12:03:16 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:03:16 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:03:16 --> 404 Page Not Found: /index
ERROR - 2020-01-21 12:03:22 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:03:22 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:03:22 --> 404 Page Not Found: /index
ERROR - 2020-01-21 12:03:38 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:03:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:03:39 --> 404 Page Not Found: /index
ERROR - 2020-01-21 12:03:52 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:03:52 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:03:52 --> 404 Page Not Found: /index
ERROR - 2020-01-21 12:04:03 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:04:04 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:04:04 --> 404 Page Not Found: /index
ERROR - 2020-01-21 12:04:14 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:04:14 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:04:14 --> 404 Page Not Found: /index
ERROR - 2020-01-21 12:09:42 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:09:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:09:43 --> 404 Page Not Found: /index
ERROR - 2020-01-21 12:12:02 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:12:02 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:12:02 --> 404 Page Not Found: /index
ERROR - 2020-01-21 12:14:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:14:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:14:34 --> 404 Page Not Found: /index
ERROR - 2020-01-21 12:14:47 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:14:47 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:14:47 --> 404 Page Not Found: /index
ERROR - 2020-01-21 12:15:09 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:15:09 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:15:09 --> 404 Page Not Found: /index
ERROR - 2020-01-21 12:16:21 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:16:21 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:16:21 --> 404 Page Not Found: /index
ERROR - 2020-01-21 12:16:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:16:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:16:43 --> 404 Page Not Found: /index
ERROR - 2020-01-21 12:19:14 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:19:14 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:19:14 --> 404 Page Not Found: /index
ERROR - 2020-01-21 12:19:57 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:19:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:19:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:19:59 --> 404 Page Not Found: /index
ERROR - 2020-01-21 12:20:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:20:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:20:35 --> 404 Page Not Found: /index
ERROR - 2020-01-21 12:20:44 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:20:44 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:20:44 --> 404 Page Not Found: /index
ERROR - 2020-01-21 12:22:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:22:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:22:59 --> 404 Page Not Found: /index
ERROR - 2020-01-21 12:23:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:23:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:23:30 --> 404 Page Not Found: /index
ERROR - 2020-01-21 12:23:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:23:44 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:23:44 --> 404 Page Not Found: /index
ERROR - 2020-01-21 12:24:20 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:24:20 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:24:20 --> 404 Page Not Found: /index
ERROR - 2020-01-21 12:24:51 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:24:51 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:24:51 --> 404 Page Not Found: /index
ERROR - 2020-01-21 12:25:16 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:25:16 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:25:16 --> 404 Page Not Found: /index
ERROR - 2020-01-21 12:25:45 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:25:45 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:25:45 --> 404 Page Not Found: /index
ERROR - 2020-01-21 12:25:48 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:25:48 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:25:48 --> 404 Page Not Found: /index
ERROR - 2020-01-21 12:26:15 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:26:15 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:26:15 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:26:15 --> 404 Page Not Found: /index
ERROR - 2020-01-21 12:26:15 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:26:15 --> 404 Page Not Found: /index
ERROR - 2020-01-21 12:27:48 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:27:48 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:27:48 --> 404 Page Not Found: /index
ERROR - 2020-01-21 12:27:51 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:27:51 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:27:52 --> 404 Page Not Found: /index
ERROR - 2020-01-21 12:30:18 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:30:18 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:30:18 --> 404 Page Not Found: /index
ERROR - 2020-01-21 12:30:46 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:30:46 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:30:46 --> 404 Page Not Found: /index
ERROR - 2020-01-21 12:31:03 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:31:03 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:31:03 --> 404 Page Not Found: /index
ERROR - 2020-01-21 12:31:09 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:31:09 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:31:09 --> 404 Page Not Found: /index
ERROR - 2020-01-21 12:31:18 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:31:18 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:31:18 --> 404 Page Not Found: /index
ERROR - 2020-01-21 12:34:52 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:34:52 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:34:52 --> 404 Page Not Found: /index
ERROR - 2020-01-21 12:39:16 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:39:16 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:39:16 --> 404 Page Not Found: /index
ERROR - 2020-01-21 12:39:29 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:39:29 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:39:29 --> 404 Page Not Found: /index
ERROR - 2020-01-21 12:42:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:42:40 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:42:40 --> 404 Page Not Found: /index
ERROR - 2020-01-21 12:43:38 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:43:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:43:39 --> 404 Page Not Found: /index
ERROR - 2020-01-21 12:44:16 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:44:16 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:44:16 --> 404 Page Not Found: /index
ERROR - 2020-01-21 12:45:21 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:45:21 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:45:21 --> 404 Page Not Found: /index
ERROR - 2020-01-21 12:45:32 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:45:32 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:45:32 --> 404 Page Not Found: /index
ERROR - 2020-01-21 12:50:32 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:50:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:50:33 --> 404 Page Not Found: /index
ERROR - 2020-01-21 12:52:42 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:53:42 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:54:01 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:54:12 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:54:24 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:54:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:55:05 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:55:44 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:56:32 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:57:05 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:57:24 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:58:13 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:58:40 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:58:53 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 12:59:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:00:51 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:00:54 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:01:07 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:05:54 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:06:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:06:36 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:06:49 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:06:56 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:08:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:09:57 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:11:40 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:11:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:13:03 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:14:11 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:14:22 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:14:37 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:16:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:16:54 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:18:07 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:23:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:23:08 --> Severity: error --> Exception: Call to undefined function is_user_loggedin() C:\danxampp\htdocs\since\application\modules\usermaster\controllers\Usermaster.php 25
ERROR - 2020-01-21 13:23:27 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:23:27 --> Severity: error --> Exception: Call to undefined function is_user_loggedin() C:\danxampp\htdocs\since\application\modules\usermaster\controllers\Usermaster.php 25
ERROR - 2020-01-21 13:23:29 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:23:29 --> Severity: error --> Exception: Call to undefined function is_user_loggedin() C:\danxampp\htdocs\since\application\modules\usermaster\controllers\Usermaster.php 25
ERROR - 2020-01-21 13:23:55 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:23:55 --> Severity: error --> Exception: Using $this when not in object context C:\danxampp\htdocs\since\application\helpers\funcus_helper.php 175
ERROR - 2020-01-21 13:24:10 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:24:10 --> Severity: error --> Exception: Using $this when not in object context C:\danxampp\htdocs\since\application\helpers\funcus_helper.php 175
ERROR - 2020-01-21 13:26:29 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:27:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:27:22 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:27:22 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:27:32 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:27:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:27:35 --> 404 Page Not Found: /index
ERROR - 2020-01-21 13:27:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:27:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:27:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:27:48 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:27:51 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:27:51 --> 404 Page Not Found: /index
ERROR - 2020-01-21 13:27:53 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:27:53 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:27:56 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:27:56 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:27:58 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:27:58 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:28:01 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:28:01 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:28:06 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:28:06 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:28:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:28:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:28:52 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:29:38 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:29:56 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:30:00 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:30:00 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:30:00 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:30:01 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:30:26 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:30:26 --> 404 Page Not Found: /index
ERROR - 2020-01-21 13:30:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:31:00 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 13:31:18 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 14:13:15 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 14:13:46 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 14:13:46 --> Severity: Notice --> Undefined variable: getData C:\danxampp\htdocs\since\application\modules\usermaster\controllers\Usermaster.php 41
ERROR - 2020-01-21 14:13:46 --> Severity: Notice --> Undefined variable: getData C:\danxampp\htdocs\since\application\modules\usermaster\controllers\Usermaster.php 42
ERROR - 2020-01-21 14:13:46 --> Severity: Notice --> Undefined variable: getData C:\danxampp\htdocs\since\application\modules\usermaster\controllers\Usermaster.php 43
ERROR - 2020-01-21 14:13:46 --> Severity: Notice --> Undefined variable: getData C:\danxampp\htdocs\since\application\modules\usermaster\controllers\Usermaster.php 44
ERROR - 2020-01-21 14:30:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 14:30:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 14:32:29 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 14:32:29 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 14:32:38 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 14:32:38 --> Query error: Duplicate entry 'mohddanish8564@gmail.com' for key 'email' - Invalid query: INSERT INTO `user_login` (`firstname`, `lastname`, `gender`, `email`, `mobile_no`, `role`, `pass`, `status`, `post_date`) VALUES ('danish', 'Mishra', 'male', 'mohddanish8564@gmail.com', '8564957155', '1', 'e9552e1f0d981654ea5e8400a69c1c7f', 1, '2020-01-21')
ERROR - 2020-01-21 14:32:38 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 14:33:03 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 14:33:03 --> Query error: Duplicate entry 'mohddanish8564@gmail.com' for key 'email' - Invalid query: INSERT INTO `user_login` (`firstname`, `lastname`, `gender`, `email`, `mobile_no`, `role`, `pass`, `status`, `post_date`) VALUES ('danish', 'Mishra', 'male', 'mohddanish8564@gmail.com', '8564957155', '1', 'a55c08bc81293358b1fbf84bca432083', 1, '2020-01-21')
ERROR - 2020-01-21 14:33:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 14:33:33 --> Query error: Duplicate entry 'mohddanish8564@gmail.com' for key 'email' - Invalid query: INSERT INTO `user_login` (`firstname`, `lastname`, `gender`, `email`, `mobile_no`, `role`, `pass`, `status`, `post_date`) VALUES ('danish', 'Mishra', 'male', 'mohddanish8564@gmail.com', '8564957155', '1', 'a55c08bc81293358b1fbf84bca432083', 1, '2020-01-21')
ERROR - 2020-01-21 14:33:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 14:37:44 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 14:39:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 14:39:27 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 14:47:42 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 14:47:58 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 14:48:01 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 14:48:54 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 14:49:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 14:51:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 14:51:53 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 14:51:55 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 14:52:06 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 14:54:02 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 14:54:02 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 14:54:09 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 14:54:09 --> Query error: Unknown column 'username' in 'where clause' - Invalid query: SELECT *
FROM `user_login`
WHERE `username` = 'admin'
AND `pass` = '202cb962ac59075b964b07152d234b70'
AND `status` = '1'
ERROR - 2020-01-21 14:56:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 14:56:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 14:56:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 14:56:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 14:57:37 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 14:57:37 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 14:57:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 14:57:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 14:57:45 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 14:57:46 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 14:58:14 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 14:58:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 14:58:32 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 14:59:18 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 14:59:18 --> 404 Page Not Found: /index
ERROR - 2020-01-21 14:59:19 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 14:59:20 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 14:59:24 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 14:59:45 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 14:59:45 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 14:59:47 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 14:59:57 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:02:05 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:02:25 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:03:07 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:03:47 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:03:50 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:04:11 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:04:21 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:04:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:05:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:08:13 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:08:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:11:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:11:30 --> Query error: Unknown column 'CASE WHEN role = 1 THEN "Admin" ELSE "User" END' in 'field list' - Invalid query: SELECT *, `CASE WHEN role = 1 THEN "Admin" ELSE "User" END` as `userrole`
FROM `tuser_type`
ERROR - 2020-01-21 15:13:22 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:13:22 --> Query error: Unknown column 'CASE WHEN role = 1 THEN "Admin" ELSE "User" END' in 'field list' - Invalid query: SELECT *, `CASE WHEN role = 1 THEN "Admin" ELSE "User" END` as `userrole`
FROM `user_login`
ERROR - 2020-01-21 15:14:16 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:14:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'fromuser_login' at line 1 - Invalid query: SELECT *, CASE WHEN role = 1 THEN "Admin" ELSE "User" END as userrole fromuser_login
ERROR - 2020-01-21 15:14:36 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:15:06 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:20:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:20:39 --> Severity: Notice --> Undefined index:  C:\danxampp\htdocs\since\application\modules\usermaster\views\userlist.php 62
ERROR - 2020-01-21 15:20:39 --> Severity: Notice --> Undefined index:  C:\danxampp\htdocs\since\application\modules\usermaster\views\userlist.php 62
ERROR - 2020-01-21 15:21:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:21:14 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:23:11 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:23:29 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:24:10 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:25:32 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:25:42 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:26:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:26:36 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:31:15 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:32:36 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:32:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:33:25 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:35:03 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:35:51 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:37:19 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:40:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:40:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:51:09 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:51:09 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:51:09 --> 404 Page Not Found: /index
ERROR - 2020-01-21 15:51:09 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:51:09 --> 404 Page Not Found: /index
ERROR - 2020-01-21 15:52:10 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:52:10 --> 404 Page Not Found: /index
ERROR - 2020-01-21 15:52:44 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:54:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:55:51 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:55:57 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:55:57 --> 404 Page Not Found: /index
ERROR - 2020-01-21 15:56:14 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:56:14 --> 404 Page Not Found: /index
ERROR - 2020-01-21 15:56:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:56:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:56:45 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:56:45 --> 404 Page Not Found: ../modules/usermaster/controllers/Usermaster/changepassword
ERROR - 2020-01-21 15:56:48 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:56:48 --> 404 Page Not Found: ../modules/usermaster/controllers/Usermaster/changepassword
ERROR - 2020-01-21 15:57:50 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:57:55 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 15:57:55 --> Severity: Notice --> Undefined variable: post C:\danxampp\htdocs\since\application\modules\usermaster\controllers\Usermaster.php 74
ERROR - 2020-01-21 16:04:32 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:05:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:06:07 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:06:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:06:17 --> Severity: Notice --> Undefined variable: post C:\danxampp\htdocs\since\application\modules\usermaster\controllers\Usermaster.php 74
ERROR - 2020-01-21 16:06:53 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:07:02 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:07:28 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:07:28 --> Severity: Notice --> Undefined variable: post C:\danxampp\htdocs\since\application\modules\usermaster\controllers\Usermaster.php 74
ERROR - 2020-01-21 16:07:50 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:16:31 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:16:55 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:16:55 --> Query error: Unknown column 'id=34' in 'where clause' - Invalid query: UPDATE `user_login` SET `pass`='e10adc3949ba59abbe56e057f20f883e' WHERE `id=34
ERROR - 2020-01-21 16:17:12 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:17:12 --> Severity: error --> Exception: Call to a member function result_array() on boolean C:\danxampp\htdocs\since\application\modules\function\models\Allfunction.php 80
ERROR - 2020-01-21 16:19:57 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:19:57 --> Severity: error --> Exception: syntax error, unexpected ',' C:\danxampp\htdocs\since\application\modules\usermaster\controllers\Usermaster.php 78
ERROR - 2020-01-21 16:20:16 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:22:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:22:31 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:22:49 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:23:19 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:23:22 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:23:22 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:23:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:23:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:23:40 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:23:40 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:23:46 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:23:48 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:23:49 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:23:51 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:23:53 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:24:01 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:24:04 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:24:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:25:47 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:26:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:27:04 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:27:24 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:27:36 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:27:36 --> 404 Page Not Found: /index
ERROR - 2020-01-21 16:27:38 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:27:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:27:46 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:27:46 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:28:05 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:28:05 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:28:22 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:28:22 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:28:27 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:28:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:29:29 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:29:32 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:29:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:29:33 --> 404 Page Not Found: /index
ERROR - 2020-01-21 16:29:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:29:37 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:29:38 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:29:38 --> 404 Page Not Found: /index
ERROR - 2020-01-21 16:29:40 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:29:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:29:43 --> 404 Page Not Found: /index
ERROR - 2020-01-21 16:29:44 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:30:25 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:30:26 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:30:27 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:30:28 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:30:29 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:30:44 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:38:49 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:40:46 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:41:21 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:41:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:43:09 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:43:27 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:43:27 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:43:27 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:44:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:44:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:47:09 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:51:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:52:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:52:54 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:54:13 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:54:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:54:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:54:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:55:04 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:55:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:55:55 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:56:10 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:57:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:57:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 16:58:12 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 17:00:27 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 17:01:12 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 17:02:04 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 17:06:24 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 17:06:26 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 17:10:21 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 17:10:24 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 17:11:01 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 17:11:03 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 17:19:04 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 17:21:49 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 17:22:07 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 17:22:14 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 17:24:54 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 17:25:06 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 17:25:42 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 17:26:48 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 17:27:05 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 17:27:10 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 17:27:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 17:58:11 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 17:58:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 17:58:50 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 17:58:57 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 18:28:47 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 18:28:50 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 18:28:55 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 18:29:04 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 18:36:02 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 18:36:06 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 18:39:11 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 18:39:31 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 18:39:44 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 18:40:01 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 18:40:12 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 18:40:22 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 18:55:03 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:02:10 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:03:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:03:58 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:04:05 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:04:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:26:28 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:28:55 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:28:57 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:28:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:28:59 --> 404 Page Not Found: /index
ERROR - 2020-01-21 19:31:11 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:31:53 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:32:02 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:32:07 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:32:07 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:32:11 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:32:15 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:32:15 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:32:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:32:36 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:33:55 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:34:29 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:34:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:34:34 --> Query error: Unknown column 'statusaa' in 'field list' - Invalid query: UPDATE `user_login` SET `statusaa` = '0'
WHERE `id` = '34'
ERROR - 2020-01-21 19:36:25 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:36:27 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:36:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:37:04 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:37:04 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:37:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:37:44 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:37:50 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:38:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:38:33 --> Query error: Unknown column 'status1' in 'field list' - Invalid query: UPDATE `user_login` SET `status1` = '0'
WHERE `id` = '34'
ERROR - 2020-01-21 19:38:49 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:39:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:39:23 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:39:28 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:39:31 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:39:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:39:47 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:39:50 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:39:50 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:39:52 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:39:53 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:39:55 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:39:55 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:40:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:40:50 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:41:05 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:42:25 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:42:26 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:42:32 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:42:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:42:42 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:43:10 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
ERROR - 2020-01-21 19:45:23 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\since\application\vendor/autoload.php was not found.
