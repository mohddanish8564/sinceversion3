<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-06 11:15:20 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:15:26 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:15:26 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:15:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:15:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:15:35 --> 404 Page Not Found: /index
ERROR - 2020-01-06 11:15:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:15:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:15:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:15:41 --> 404 Page Not Found: /index
ERROR - 2020-01-06 11:15:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:15:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:15:43 --> 404 Page Not Found: /index
ERROR - 2020-01-06 11:15:45 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:15:45 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:15:45 --> 404 Page Not Found: /index
ERROR - 2020-01-06 11:16:00 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:16:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:16:18 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:16:19 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:16:20 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:16:20 --> 404 Page Not Found: /index
ERROR - 2020-01-06 11:17:40 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:18:04 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:18:05 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:18:07 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:18:07 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:18:07 --> 404 Page Not Found: /index
ERROR - 2020-01-06 11:18:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:18:18 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:18:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:18:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:18:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:18:59 --> 404 Page Not Found: /index
ERROR - 2020-01-06 11:19:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:20:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:20:53 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:21:37 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:21:37 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:21:37 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:21:37 --> 404 Page Not Found: /index
ERROR - 2020-01-06 11:21:49 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:21:49 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:21:49 --> 404 Page Not Found: /index
ERROR - 2020-01-06 11:21:53 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:21:53 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:21:53 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:21:53 --> 404 Page Not Found: /index
ERROR - 2020-01-06 11:22:01 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:22:01 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:22:02 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:22:02 --> 404 Page Not Found: /index
ERROR - 2020-01-06 11:30:37 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:30:37 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:30:37 --> 404 Page Not Found: /index
ERROR - 2020-01-06 11:30:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:30:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:30:44 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:30:44 --> 404 Page Not Found: /index
ERROR - 2020-01-06 11:30:57 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:30:57 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:30:57 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:30:57 --> 404 Page Not Found: /index
ERROR - 2020-01-06 11:31:13 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:31:13 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:31:13 --> 404 Page Not Found: /index
ERROR - 2020-01-06 11:31:22 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:31:22 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:31:23 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:31:23 --> 404 Page Not Found: /index
ERROR - 2020-01-06 11:32:51 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:32:52 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:32:52 --> 404 Page Not Found: /index
ERROR - 2020-01-06 11:32:56 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:32:56 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:32:56 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:32:56 --> 404 Page Not Found: /index
ERROR - 2020-01-06 11:35:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:35:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:35:35 --> 404 Page Not Found: /index
ERROR - 2020-01-06 11:35:40 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:37:48 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:37:50 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:37:52 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:37:52 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:37:52 --> 404 Page Not Found: /index
ERROR - 2020-01-06 11:37:56 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:38:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:38:08 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 299
ERROR - 2020-01-06 11:38:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:38:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:38:08 --> 404 Page Not Found: /index
ERROR - 2020-01-06 11:38:22 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:38:22 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 299
ERROR - 2020-01-06 11:38:22 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:38:23 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:38:23 --> 404 Page Not Found: /index
ERROR - 2020-01-06 11:38:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:38:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:38:43 --> 404 Page Not Found: /index
ERROR - 2020-01-06 11:38:49 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:38:49 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 300
ERROR - 2020-01-06 11:38:49 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:38:49 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:38:49 --> 404 Page Not Found: /index
ERROR - 2020-01-06 11:39:25 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:39:25 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:39:26 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:39:26 --> 404 Page Not Found: /index
ERROR - 2020-01-06 11:40:47 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:40:47 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 302
ERROR - 2020-01-06 11:40:47 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:40:47 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:40:47 --> 404 Page Not Found: /index
ERROR - 2020-01-06 11:41:45 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:41:45 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:41:45 --> 404 Page Not Found: /index
ERROR - 2020-01-06 11:41:49 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:41:49 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 302
ERROR - 2020-01-06 11:41:49 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:41:49 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:41:49 --> 404 Page Not Found: /index
ERROR - 2020-01-06 11:42:11 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:42:11 --> Severity: error --> Exception: syntax error, unexpected '$row' (T_VARIABLE) C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 240
ERROR - 2020-01-06 11:42:13 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:42:13 --> Severity: error --> Exception: syntax error, unexpected '$row' (T_VARIABLE) C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 240
ERROR - 2020-01-06 11:42:19 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:42:20 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:42:20 --> 404 Page Not Found: /index
ERROR - 2020-01-06 11:42:24 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:42:24 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:42:24 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:42:24 --> 404 Page Not Found: /index
ERROR - 2020-01-06 11:42:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:42:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:42:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:42:31 --> 404 Page Not Found: /index
ERROR - 2020-01-06 11:42:36 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:43:24 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:43:25 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 306
ERROR - 2020-01-06 11:44:05 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:44:05 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 304
ERROR - 2020-01-06 11:44:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:44:30 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 299
ERROR - 2020-01-06 11:45:06 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:45:06 --> Severity: Notice --> Undefined variable: row C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 296
ERROR - 2020-01-06 11:45:06 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 299
ERROR - 2020-01-06 11:45:06 --> Severity: Notice --> Undefined variable: row C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 309
ERROR - 2020-01-06 11:46:02 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:46:03 --> Severity: Notice --> Undefined variable: row C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 298
ERROR - 2020-01-06 11:46:03 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 301
ERROR - 2020-01-06 11:46:03 --> Severity: Notice --> Undefined variable: row C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 311
ERROR - 2020-01-06 11:46:05 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:46:05 --> Severity: Notice --> Undefined variable: row C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 298
ERROR - 2020-01-06 11:46:05 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 301
ERROR - 2020-01-06 11:46:05 --> Severity: Notice --> Undefined variable: row C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 311
ERROR - 2020-01-06 11:46:27 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:46:27 --> Severity: Notice --> Undefined variable: row C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 300
ERROR - 2020-01-06 11:46:27 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 303
ERROR - 2020-01-06 11:46:27 --> Severity: Notice --> Undefined variable: row C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 313
ERROR - 2020-01-06 11:47:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:47:57 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:47:57 --> Query error: Duplicate entry '10024' for key 'PRIMARY' - Invalid query: INSERT INTO `import_smecompanies` (`enterprise_id`, `name`, `is_sme`, `region`, `consortium`, `since_supported`, `value_chain`, `status`, `postdate`) VALUES ('10024', 'XYZ Company', 'Yes', 'Addis Ababa', 'Lot1', 'Yes', 'Construction', 1, '2020-01-06')
ERROR - 2020-01-06 11:48:10 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:48:10 --> Query error: Duplicate entry '10024' for key 'PRIMARY' - Invalid query: INSERT INTO `import_smecompanies` (`enterprise_id`, `name`, `is_sme`, `region`, `consortium`, `since_supported`, `value_chain`, `status`, `postdate`) VALUES ('10024', 'XYZ Company', 'Yes', 'Addis Ababa', 'Lot1', 'Yes', 'Construction', 1, '2020-01-06')
ERROR - 2020-01-06 11:48:10 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:48:10 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 51
ERROR - 2020-01-06 11:48:10 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:48:10 --> 404 Page Not Found: /index
ERROR - 2020-01-06 11:50:48 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:50:49 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:50:49 --> 404 Page Not Found: /index
ERROR - 2020-01-06 11:51:07 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:51:07 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 306
ERROR - 2020-01-06 11:51:07 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:51:07 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:51:07 --> 404 Page Not Found: /index
ERROR - 2020-01-06 11:51:22 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:51:49 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:51:51 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:51:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:52:06 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:52:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:52:10 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:52:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:52:49 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:52:57 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:52:57 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 247
ERROR - 2020-01-06 11:53:02 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:53:32 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:53:32 --> Query error: Duplicate entry '10024' for key 'PRIMARY' - Invalid query: INSERT INTO `import_smecompanies` (`enterprise_id`, `name`, `is_sme`, `region`, `consortium`, `since_supported`, `value_chain`, `status`, `postdate`) VALUES ('10024', 'XYZ Company', 'Yes', 'Addis Ababa', 'Lot1', 'Yes', 'Construction', 1, '2020-01-06')
ERROR - 2020-01-06 11:53:32 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:53:33 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 51
ERROR - 2020-01-06 11:53:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:53:33 --> 404 Page Not Found: /index
ERROR - 2020-01-06 11:53:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:53:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:53:41 --> 404 Page Not Found: /index
ERROR - 2020-01-06 11:53:45 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:53:46 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 306
ERROR - 2020-01-06 11:53:46 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:53:46 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:53:46 --> 404 Page Not Found: /index
ERROR - 2020-01-06 11:54:24 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:54:24 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:54:25 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:54:25 --> 404 Page Not Found: /index
ERROR - 2020-01-06 11:54:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:54:30 --> Query error: Duplicate entry '10024' for key 'PRIMARY' - Invalid query: INSERT INTO `import_smecompanies` (`enterprise_id`, `name`, `is_sme`, `region`, `consortium`, `since_supported`, `value_chain`, `status`, `postdate`) VALUES ('10024', 'XYZ Company', 'Yes', 'Addis Ababa', 'Lot1', 'Yes', 'Construction', 1, '2020-01-06')
ERROR - 2020-01-06 11:54:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:54:30 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 51
ERROR - 2020-01-06 11:54:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:54:30 --> 404 Page Not Found: /index
ERROR - 2020-01-06 11:55:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:55:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:55:39 --> 404 Page Not Found: /index
ERROR - 2020-01-06 11:55:44 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:55:44 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:55:44 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:55:44 --> 404 Page Not Found: /index
ERROR - 2020-01-06 11:55:49 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:55:49 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:55:50 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:55:50 --> 404 Page Not Found: /index
ERROR - 2020-01-06 11:56:23 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:56:23 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:56:23 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:56:23 --> 404 Page Not Found: /index
ERROR - 2020-01-06 11:56:26 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:56:26 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:56:26 --> 404 Page Not Found: /index
ERROR - 2020-01-06 11:56:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:57:11 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:57:21 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:57:21 --> Query error: Duplicate entry '10024' for key 'PRIMARY' - Invalid query: INSERT INTO `import_smecompanies` (`enterprise_id`, `name`, `is_sme`, `region`, `consortium`, `since_supported`, `value_chain`, `status`, `postdate`) VALUES ('10024', 'XYZ Company', 'Yes', 'Addis Ababa', 'Lot1', 'Yes', 'Construction', 1, '2020-01-06')
ERROR - 2020-01-06 11:57:21 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:57:21 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 51
ERROR - 2020-01-06 11:57:21 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:57:21 --> 404 Page Not Found: /index
ERROR - 2020-01-06 11:58:11 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:58:11 --> Severity: error --> Exception: syntax error, unexpected ';' C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 321
ERROR - 2020-01-06 11:58:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:58:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:58:17 --> 404 Page Not Found: /index
ERROR - 2020-01-06 11:58:22 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:58:22 --> Query error: Duplicate entry '10024' for key 'PRIMARY' - Invalid query: INSERT INTO `import_smecompanies` (`enterprise_id`, `name`, `is_sme`, `region`, `consortium`, `since_supported`, `value_chain`, `status`, `postdate`) VALUES ('10024', 'XYZ Company', 'Yes', 'Addis Ababa', 'Lot1', 'Yes', 'Construction', 1, '2020-01-06')
ERROR - 2020-01-06 11:58:22 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:58:22 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 51
ERROR - 2020-01-06 11:58:22 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:58:22 --> 404 Page Not Found: /index
ERROR - 2020-01-06 11:59:53 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:59:53 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:59:53 --> 404 Page Not Found: /index
ERROR - 2020-01-06 11:59:58 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:59:58 --> Query error: Duplicate entry '10024' for key 'PRIMARY' - Invalid query: INSERT INTO `import_smecompanies` (`enterprise_id`, `name`, `is_sme`, `region`, `consortium`, `since_supported`, `value_chain`, `status`, `postdate`) VALUES ('10024', 'XYZ Company', 'Yes', 'Addis Ababa', 'Lot1', 'Yes', 'Construction', 1, '2020-01-06')
ERROR - 2020-01-06 11:59:58 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:59:58 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 51
ERROR - 2020-01-06 11:59:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 11:59:59 --> 404 Page Not Found: /index
ERROR - 2020-01-06 12:00:09 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:00:09 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:00:09 --> 404 Page Not Found: /index
ERROR - 2020-01-06 12:00:14 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:00:55 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:00:55 --> Query error: Duplicate entry '10024' for key 'PRIMARY' - Invalid query: INSERT INTO `import_smecompanies` (`enterprise_id`, `name`, `is_sme`, `region`, `consortium`, `since_supported`, `value_chain`, `status`, `postdate`) VALUES ('10024', 'XYZ Company', 'Yes', 'Addis Ababa', 'Lot1', 'Yes', 'Construction', 1, '2020-01-06')
ERROR - 2020-01-06 12:00:55 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:00:55 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 51
ERROR - 2020-01-06 12:00:55 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:00:55 --> 404 Page Not Found: /index
ERROR - 2020-01-06 12:01:18 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:01:19 --> Query error: Duplicate entry '10024' for key 'PRIMARY' - Invalid query: INSERT INTO `import_smecompanies` (`enterprise_id`, `name`, `is_sme`, `region`, `consortium`, `since_supported`, `value_chain`, `status`, `postdate`) VALUES ('10024', 'XYZ Company', 'Yes', 'Addis Ababa', 'Lot1', 'Yes', 'Construction', 1, '2020-01-06')
ERROR - 2020-01-06 12:01:19 --> Query error: Duplicate entry '10025' for key 'PRIMARY' - Invalid query: INSERT INTO `import_smecompanies` (`enterprise_id`, `name`, `is_sme`, `region`, `consortium`, `since_supported`, `value_chain`, `status`, `postdate`) VALUES ('10025', 'XYZ Company', 'Yes', 'Addis Ababa', 'Lot1', 'Yes', 'Construction', 1, '2020-01-06')
ERROR - 2020-01-06 12:01:19 --> Query error: Duplicate entry '10026' for key 'PRIMARY' - Invalid query: INSERT INTO `import_smecompanies` (`enterprise_id`, `name`, `is_sme`, `region`, `consortium`, `since_supported`, `value_chain`, `status`, `postdate`) VALUES ('10026', 'XYZ Company', 'Yes', 'Addis Ababa', 'Lot1', 'Yes', 'Construction', 1, '2020-01-06')
ERROR - 2020-01-06 12:01:19 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:01:19 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 51
ERROR - 2020-01-06 12:01:19 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:01:19 --> 404 Page Not Found: /index
ERROR - 2020-01-06 12:01:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:01:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:01:59 --> 404 Page Not Found: /index
ERROR - 2020-01-06 12:02:00 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:02:00 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:02:00 --> 404 Page Not Found: /index
ERROR - 2020-01-06 12:02:05 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:02:05 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:02:05 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:02:05 --> 404 Page Not Found: /index
ERROR - 2020-01-06 12:04:09 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:04:09 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:04:09 --> 404 Page Not Found: /index
ERROR - 2020-01-06 12:04:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:04:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:04:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:04:17 --> 404 Page Not Found: /index
ERROR - 2020-01-06 12:10:58 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:10:58 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:10:58 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:10:58 --> 404 Page Not Found: /index
ERROR - 2020-01-06 12:12:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:12:33 --> Query error: Duplicate entry '10024' for key 'PRIMARY' - Invalid query: INSERT INTO `import_smecompanies` (`enterprise_id`, `name`, `is_sme`, `region`, `consortium`, `since_supported`, `value_chain`, `status`, `postdate`) VALUES ('10024', 'XYZ Company', 'Yes', 'Addis Ababa', 'Lot1', 'Yes', 'Construction', 1, '2020-01-06')
ERROR - 2020-01-06 12:12:33 --> Query error: Duplicate entry '10025' for key 'PRIMARY' - Invalid query: INSERT INTO `import_smecompanies` (`enterprise_id`, `name`, `is_sme`, `region`, `consortium`, `since_supported`, `value_chain`, `status`, `postdate`) VALUES ('10025', 'XYZ Company', 'Yes', 'Addis Ababa', 'Lot1', 'Yes', 'Construction', 1, '2020-01-06')
ERROR - 2020-01-06 12:12:33 --> Query error: Duplicate entry '10026' for key 'PRIMARY' - Invalid query: INSERT INTO `import_smecompanies` (`enterprise_id`, `name`, `is_sme`, `region`, `consortium`, `since_supported`, `value_chain`, `status`, `postdate`) VALUES ('10026', 'XYZ Company', 'Yes', 'Addis Ababa', 'Lot1', 'Yes', 'Construction', 1, '2020-01-06')
ERROR - 2020-01-06 12:12:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:12:33 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 51
ERROR - 2020-01-06 12:12:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:12:33 --> 404 Page Not Found: /index
ERROR - 2020-01-06 12:13:58 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:13:58 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:13:58 --> 404 Page Not Found: /index
ERROR - 2020-01-06 12:14:18 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:14:18 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:14:18 --> 404 Page Not Found: /index
ERROR - 2020-01-06 12:14:24 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:18:52 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:18:52 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 444
ERROR - 2020-01-06 12:18:52 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:18:52 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:18:52 --> 404 Page Not Found: /index
ERROR - 2020-01-06 12:19:03 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:19:03 --> Query error: Duplicate entry '223434' for key 'PRIMARY' - Invalid query: INSERT INTO `import_beneficiary_trainings` (`beneficiary_id`, `tvet_id`, `training_module`, `start_date`, `end_date`, `status`, `postdate`) VALUES ('223434', '3445', 'Leather Goods-2-VIS( Entoto PTC )', '2019-03-05', '1970-01-01', 1, '2020-01-06')
ERROR - 2020-01-06 12:19:04 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:19:04 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 51
ERROR - 2020-01-06 12:19:04 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:19:04 --> 404 Page Not Found: /index
ERROR - 2020-01-06 12:19:19 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:19:20 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:19:20 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:19:20 --> 404 Page Not Found: /index
ERROR - 2020-01-06 12:19:27 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:19:28 --> Query error: Duplicate entry '223434' for key 'PRIMARY' - Invalid query: INSERT INTO `import_beneficiary_trainings` (`beneficiary_id`, `tvet_id`, `training_module`, `start_date`, `end_date`, `status`, `postdate`) VALUES ('223434', '3445', 'Leather Goods-2-VIS( Entoto PTC )', '2019-03-05', '1970-01-01', 1, '2020-01-06')
ERROR - 2020-01-06 12:19:28 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:19:28 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 51
ERROR - 2020-01-06 12:19:28 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:19:28 --> 404 Page Not Found: /index
ERROR - 2020-01-06 12:21:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:21:44 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:21:44 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:21:44 --> 404 Page Not Found: /index
ERROR - 2020-01-06 12:22:19 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:22:19 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:22:19 --> 404 Page Not Found: /index
ERROR - 2020-01-06 12:22:23 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:22:23 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:22:24 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:22:24 --> 404 Page Not Found: /index
ERROR - 2020-01-06 12:23:03 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:23:04 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:23:04 --> 404 Page Not Found: /index
ERROR - 2020-01-06 12:23:14 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:23:15 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:23:15 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:23:15 --> 404 Page Not Found: /index
ERROR - 2020-01-06 12:23:31 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:23:32 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:23:32 --> 404 Page Not Found: /index
ERROR - 2020-01-06 12:24:28 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:24:28 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:24:28 --> 404 Page Not Found: /index
ERROR - 2020-01-06 12:26:13 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:26:13 --> Query error: Duplicate entry '223434' for key 'PRIMARY' - Invalid query: INSERT INTO `import_beneficiary_trainings` (`beneficiary_id`, `tvet_id`, `training_module`, `start_date`, `end_date`, `status`, `postdate`) VALUES ('223434', '3445', 'Leather Goods-2-VIS( Entoto PTC )', '2019-03-05', '1970-01-01', 1, '2020-01-06')
ERROR - 2020-01-06 12:26:13 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:26:13 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 51
ERROR - 2020-01-06 12:26:13 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:26:13 --> 404 Page Not Found: /index
ERROR - 2020-01-06 12:37:22 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:37:23 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:37:23 --> 404 Page Not Found: /index
ERROR - 2020-01-06 12:38:37 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:38:37 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:38:38 --> 404 Page Not Found: /index
ERROR - 2020-01-06 12:38:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:38:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:38:39 --> 404 Page Not Found: /index
ERROR - 2020-01-06 12:44:21 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:44:21 --> 404 Page Not Found: /index
ERROR - 2020-01-06 12:44:23 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:44:23 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:44:23 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:44:23 --> 404 Page Not Found: /index
ERROR - 2020-01-06 12:44:48 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:44:48 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:44:53 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:44:53 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:44:53 --> 404 Page Not Found: /index
ERROR - 2020-01-06 12:52:29 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:52:29 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:52:29 --> 404 Page Not Found: /index
ERROR - 2020-01-06 12:52:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:52:48 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:58:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:58:36 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:58:36 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:58:36 --> 404 Page Not Found: /index
ERROR - 2020-01-06 12:58:40 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:58:40 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 12:58:40 --> 404 Page Not Found: /index
ERROR - 2020-01-06 12:59:01 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:00:57 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:00:57 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:00:57 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:00:58 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:01:03 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:01:03 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:01:03 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:01:05 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:01:05 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:01:05 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:01:07 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:01:07 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:01:07 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:01:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:01:18 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:01:18 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:01:18 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:01:24 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:01:24 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:01:25 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:01:25 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:01:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:01:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:01:31 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:01:31 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:01:45 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:01:46 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:01:46 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:01:51 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:01:51 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:01:51 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:01:56 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:01:57 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 585
ERROR - 2020-01-06 13:01:57 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:01:57 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:01:57 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:02:18 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:02:18 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:02:18 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:02:24 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:02:46 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:02:46 --> Query error: Duplicate entry '223434' for key 'PRIMARY' - Invalid query: INSERT INTO `import_beneficiaries` (`beneficiary_id`, `sex`, `region`, `entry_date_to_since`, `target_group`, `value_chain`, `entry_point_income`, `endline_income`, `type_of_income`, `disabled`, `consortium`, `status`, `postdate`) VALUES ('223434', 'Male', 'Addis Ababa', '2019-02-07', 'Youth (Potential Migrant)', 'Construction', '455', '688', 'Formal Income', 'NO ', 'Lot1', 1, '2020-01-06')
ERROR - 2020-01-06 13:04:29 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:04:29 --> Query error: Duplicate entry '223434' for key 'PRIMARY' - Invalid query: INSERT INTO `import_beneficiaries` (`beneficiary_id`, `sex`, `region`, `entry_date_to_since`, `target_group`, `value_chain`, `entry_point_income`, `endline_income`, `type_of_income`, `disabled`, `consortium`, `status`, `postdate`) VALUES ('223434', 'Male', 'Addis Ababa', '2019-02-07', 'Youth (Potential Migrant)', 'Construction', '455', '688', 'Formal Income', 'NO ', 'Lot1', 1, '2020-01-06')
ERROR - 2020-01-06 13:04:29 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:04:29 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 51
ERROR - 2020-01-06 13:04:29 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:04:29 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:04:36 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:04:36 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:04:36 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:04:36 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:04:42 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:04:42 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:04:42 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:04:42 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:04:51 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:04:51 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:04:51 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:04:51 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:04:56 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:04:56 --> Query error: Duplicate entry '223434' for key 'PRIMARY' - Invalid query: INSERT INTO `import_beneficiaries` (`beneficiary_id`, `sex`, `region`, `entry_date_to_since`, `target_group`, `value_chain`, `entry_point_income`, `endline_income`, `type_of_income`, `disabled`, `consortium`, `status`, `postdate`) VALUES ('223434', 'Male', 'Addis Ababa', '2019-02-07', 'Youth (Potential Migrant)', 'Construction', '455', '688', 'Formal Income', 'NO ', 'Lot1', 1, '2020-01-06')
ERROR - 2020-01-06 13:04:56 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:04:56 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 51
ERROR - 2020-01-06 13:04:56 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:04:56 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:05:04 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:05:04 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:05:04 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:05:09 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:05:09 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 592
ERROR - 2020-01-06 13:05:09 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:05:09 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:05:09 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:06:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:06:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:06:30 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:07:11 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:07:12 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:07:12 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:07:16 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:08:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:08:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:08:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:08:17 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:10:32 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:12:26 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:13:20 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:14:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:14:34 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 728
ERROR - 2020-01-06 13:14:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:14:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:14:35 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:15:24 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:15:27 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:15:27 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:15:27 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:15:37 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:15:37 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:15:37 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:15:37 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:15:42 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:15:42 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:15:42 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:15:42 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:15:51 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:15:51 --> Query error: Duplicate entry '223434' for key 'PRIMARY' - Invalid query: INSERT INTO `import_beneficiary_trainings` (`beneficiary_id`, `tvet_id`, `training_module`, `start_date`, `end_date`, `status`, `postdate`) VALUES ('223434', '3445', 'Leather Goods-2-VIS( Entoto PTC )', '2019-03-05', '1970-01-01', 1, '2020-01-06')
ERROR - 2020-01-06 13:15:52 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:15:52 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 51
ERROR - 2020-01-06 13:15:52 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:15:52 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:15:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:15:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:15:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:15:59 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:16:03 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:16:03 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:16:03 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:16:03 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:16:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:16:08 --> Query error: Duplicate entry '3448' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3448', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-06')
ERROR - 2020-01-06 13:16:08 --> Query error: Duplicate entry '3450' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3450', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-06')
ERROR - 2020-01-06 13:16:08 --> Query error: Duplicate entry '3451' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3451', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-06')
ERROR - 2020-01-06 13:16:08 --> Query error: Duplicate entry '3452' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3452', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-06')
ERROR - 2020-01-06 13:16:08 --> Query error: Duplicate entry '3453' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3453', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-06')
ERROR - 2020-01-06 13:16:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:16:08 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 51
ERROR - 2020-01-06 13:16:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:16:08 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:16:20 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:16:20 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:16:20 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:16:20 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:16:26 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:16:26 --> Query error: Duplicate entry '10024' for key 'PRIMARY' - Invalid query: INSERT INTO `import_smecompanies` (`enterprise_id`, `name`, `is_sme`, `region`, `consortium`, `since_supported`, `value_chain`, `status`, `postdate`) VALUES ('10024', 'XYZ Company', 'Yes', 'Addis Ababa', 'Lot1', 'Yes', 'Construction', 1, '2020-01-06')
ERROR - 2020-01-06 13:16:26 --> Query error: Duplicate entry '10025' for key 'PRIMARY' - Invalid query: INSERT INTO `import_smecompanies` (`enterprise_id`, `name`, `is_sme`, `region`, `consortium`, `since_supported`, `value_chain`, `status`, `postdate`) VALUES ('10025', 'XYZ Company', 'Yes', 'Addis Ababa', 'Lot1', 'Yes', 'Construction', 1, '2020-01-06')
ERROR - 2020-01-06 13:16:26 --> Query error: Duplicate entry '10026' for key 'PRIMARY' - Invalid query: INSERT INTO `import_smecompanies` (`enterprise_id`, `name`, `is_sme`, `region`, `consortium`, `since_supported`, `value_chain`, `status`, `postdate`) VALUES ('10026', 'XYZ Company', 'Yes', 'Addis Ababa', 'Lot1', 'Yes', 'Construction', 1, '2020-01-06')
ERROR - 2020-01-06 13:16:26 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:16:26 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 51
ERROR - 2020-01-06 13:16:26 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:16:26 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:17:14 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:17:14 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:17:16 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:17:16 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:17:16 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:17:17 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:17:21 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:17:22 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:17:24 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:17:24 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:17:24 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:17:57 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:17:57 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:17:57 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:18:02 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:18:02 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:18:02 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:18:02 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:18:07 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:18:07 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 600
ERROR - 2020-01-06 13:18:07 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:18:07 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:18:07 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:18:13 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:18:13 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:18:13 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:18:14 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:18:23 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:18:23 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 728
ERROR - 2020-01-06 13:18:23 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:18:23 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:18:23 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:18:29 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:18:29 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:18:29 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:18:29 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:18:36 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:18:36 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 461
ERROR - 2020-01-06 13:18:36 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:18:37 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:18:37 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:18:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:18:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:18:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:18:41 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:18:46 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:18:46 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 333
ERROR - 2020-01-06 13:18:47 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:18:47 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:18:47 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:18:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:18:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:18:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:18:59 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:19:04 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:19:04 --> Query error: Duplicate entry '3449' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3449', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-06')
ERROR - 2020-01-06 13:19:04 --> Query error: Duplicate entry '3448' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3448', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-06')
ERROR - 2020-01-06 13:19:04 --> Query error: Duplicate entry '3450' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3450', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-06')
ERROR - 2020-01-06 13:19:04 --> Query error: Duplicate entry '3451' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3451', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-06')
ERROR - 2020-01-06 13:19:04 --> Query error: Duplicate entry '3452' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3452', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-06')
ERROR - 2020-01-06 13:19:04 --> Query error: Duplicate entry '3453' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3453', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-06')
ERROR - 2020-01-06 13:19:04 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:19:04 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 51
ERROR - 2020-01-06 13:19:04 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:19:04 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:19:19 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:19:19 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:19:19 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:19:25 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:19:25 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:19:26 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:19:26 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:19:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:19:30 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 206
ERROR - 2020-01-06 13:19:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:19:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:19:30 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:19:36 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:19:36 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:19:36 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:19:42 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:21:24 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:21:25 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:21:26 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:21:26 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:22:25 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:22:25 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:22:25 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:22:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:22:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:22:33 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:22:48 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:22:49 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:22:49 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:22:50 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:22:50 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:22:50 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:22:51 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:22:51 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:22:51 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:22:52 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:22:52 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:22:52 --> 404 Page Not Found: /index
ERROR - 2020-01-06 13:22:53 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:22:53 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 13:22:53 --> 404 Page Not Found: /index
ERROR - 2020-01-06 14:11:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:12:03 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:12:36 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:13:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:14:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:14:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:14:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:26:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:26:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:26:59 --> 404 Page Not Found: /index
ERROR - 2020-01-06 14:27:01 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:27:10 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:27:21 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:27:55 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:27:55 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:27:55 --> 404 Page Not Found: /index
ERROR - 2020-01-06 14:38:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:38:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:38:17 --> 404 Page Not Found: /index
ERROR - 2020-01-06 14:38:38 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:39:13 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:39:13 --> 404 Page Not Found: /index
ERROR - 2020-01-06 14:39:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:39:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:39:30 --> 404 Page Not Found: /index
ERROR - 2020-01-06 14:40:15 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:40:15 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:40:15 --> 404 Page Not Found: /index
ERROR - 2020-01-06 14:40:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:40:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:40:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:40:39 --> 404 Page Not Found: /index
ERROR - 2020-01-06 14:43:25 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:43:26 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:43:26 --> 404 Page Not Found: /index
ERROR - 2020-01-06 14:43:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:43:31 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:43:31 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:43:31 --> 404 Page Not Found: /index
ERROR - 2020-01-06 14:44:32 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:44:32 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:44:32 --> 404 Page Not Found: /index
ERROR - 2020-01-06 14:45:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:45:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:45:34 --> 404 Page Not Found: /index
ERROR - 2020-01-06 14:45:36 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:45:36 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:45:36 --> 404 Page Not Found: /index
ERROR - 2020-01-06 14:45:38 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:45:38 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:45:38 --> 404 Page Not Found: /index
ERROR - 2020-01-06 14:46:02 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:46:02 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:46:02 --> 404 Page Not Found: /index
ERROR - 2020-01-06 14:46:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:46:08 --> 404 Page Not Found: /index
ERROR - 2020-01-06 14:46:13 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:46:14 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:46:14 --> 404 Page Not Found: /index
ERROR - 2020-01-06 14:46:15 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:46:15 --> 404 Page Not Found: /index
ERROR - 2020-01-06 14:46:16 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:46:16 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:46:16 --> 404 Page Not Found: /index
ERROR - 2020-01-06 14:46:18 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:46:20 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:46:20 --> 404 Page Not Found: /index
ERROR - 2020-01-06 14:46:22 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:46:22 --> 404 Page Not Found: /index
ERROR - 2020-01-06 14:46:24 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:46:27 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:46:49 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:47:04 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:47:04 --> 404 Page Not Found: /index
ERROR - 2020-01-06 14:47:25 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:47:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:47:36 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:47:36 --> 404 Page Not Found: /index
ERROR - 2020-01-06 14:47:44 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:47:46 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:47:47 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:47:47 --> 404 Page Not Found: /index
ERROR - 2020-01-06 14:47:56 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:47:56 --> 404 Page Not Found: /index
ERROR - 2020-01-06 14:48:03 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:48:03 --> 404 Page Not Found: /index
ERROR - 2020-01-06 14:48:24 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:48:25 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:48:25 --> 404 Page Not Found: /index
ERROR - 2020-01-06 14:48:28 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:48:28 --> 404 Page Not Found: /index
ERROR - 2020-01-06 14:48:31 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:48:31 --> 404 Page Not Found: /index
ERROR - 2020-01-06 14:48:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:48:33 --> 404 Page Not Found: /index
ERROR - 2020-01-06 14:48:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:48:35 --> 404 Page Not Found: /index
ERROR - 2020-01-06 14:48:37 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:48:37 --> 404 Page Not Found: /index
ERROR - 2020-01-06 14:48:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:48:41 --> 404 Page Not Found: /index
ERROR - 2020-01-06 14:48:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:48:43 --> 404 Page Not Found: /index
ERROR - 2020-01-06 14:48:45 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:48:45 --> 404 Page Not Found: /index
ERROR - 2020-01-06 14:48:47 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:48:47 --> 404 Page Not Found: /index
ERROR - 2020-01-06 14:48:49 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:48:49 --> 404 Page Not Found: /index
ERROR - 2020-01-06 14:48:51 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:48:51 --> 404 Page Not Found: /index
ERROR - 2020-01-06 14:48:57 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:48:57 --> 404 Page Not Found: /index
ERROR - 2020-01-06 14:48:58 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:48:58 --> 404 Page Not Found: /index
ERROR - 2020-01-06 14:48:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:49:03 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:49:05 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:49:07 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:49:28 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:49:28 --> 404 Page Not Found: /index
ERROR - 2020-01-06 14:49:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:49:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:49:31 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:49:31 --> 404 Page Not Found: /index
ERROR - 2020-01-06 14:57:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:57:15 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:58:53 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:59:49 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 14:59:49 --> Severity: Notice --> Undefined variable: title C:\danxampp\htdocs\demo\application\modules\admintemplate\views\head.php 6
ERROR - 2020-01-06 15:05:57 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:05:57 --> Severity: Notice --> Undefined variable: title C:\danxampp\htdocs\demo\application\modules\admintemplate\views\head.php 6
ERROR - 2020-01-06 15:06:44 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:06:44 --> Severity: Notice --> Undefined variable: title C:\danxampp\htdocs\demo\application\modules\admintemplate\views\head.php 6
ERROR - 2020-01-06 15:07:18 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:07:21 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:07:45 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:09:03 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:09:09 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:09:26 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:09:28 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:09:31 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:09:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:09:34 --> 404 Page Not Found: /index
ERROR - 2020-01-06 15:09:36 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:11:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:11:09 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:11:11 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:12:00 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:12:02 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:12:44 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:14:49 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:14:53 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:16:14 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:17:15 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:17:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:17:37 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:18:58 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:21:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:21:48 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:21:56 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:21:56 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:22:01 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:22:01 --> 404 Page Not Found: /index
ERROR - 2020-01-06 15:22:03 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:22:03 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:22:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:22:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:22:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:22:41 --> 404 Page Not Found: /index
ERROR - 2020-01-06 15:22:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:22:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:23:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:24:53 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:26:24 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:26:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:27:58 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:27:58 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:29:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:29:19 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:29:19 --> 404 Page Not Found: /index
ERROR - 2020-01-06 15:29:21 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:29:21 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:29:27 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:31:01 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:31:09 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:31:22 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:31:50 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:32:23 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:32:55 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:33:03 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:33:03 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:33:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:33:42 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:33:42 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:33:47 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:33:47 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:33:50 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:33:50 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:33:53 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:33:53 --> 404 Page Not Found: /index
ERROR - 2020-01-06 15:33:54 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:33:54 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:34:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:35:24 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:35:49 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:36:18 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:37:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:37:44 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:37:44 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:37:52 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:37:52 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:37:56 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:38:02 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:38:02 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:38:02 --> 404 Page Not Found: /index
ERROR - 2020-01-06 15:38:16 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:38:16 --> 404 Page Not Found: /index
ERROR - 2020-01-06 15:38:18 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:38:18 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:39:09 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:39:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:39:37 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:39:37 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:39:45 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:39:45 --> 404 Page Not Found: /index
ERROR - 2020-01-06 15:39:47 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:39:47 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:43:37 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:43:37 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:43:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:43:40 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:43:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:43:42 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:43:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:46:54 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:53:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:53:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:53:22 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:53:22 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:53:22 --> 404 Page Not Found: /index
ERROR - 2020-01-06 15:56:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:56:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:56:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 15:56:39 --> 404 Page Not Found: /index
ERROR - 2020-01-06 16:14:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:14:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:14:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:14:34 --> 404 Page Not Found: /index
ERROR - 2020-01-06 16:15:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:15:59 --> 404 Page Not Found: /index
ERROR - 2020-01-06 16:16:01 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:16:01 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:16:01 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:16:01 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:16:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:20:50 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:21:02 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:21:02 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:21:37 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:21:37 --> 404 Page Not Found: /index
ERROR - 2020-01-06 16:21:38 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:21:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:21:43 --> 404 Page Not Found: /index
ERROR - 2020-01-06 16:21:44 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:22:10 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:22:10 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:22:10 --> 404 Page Not Found: /index
ERROR - 2020-01-06 16:29:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:29:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:29:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:29:37 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:29:37 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:38:29 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:39:51 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:39:51 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:39:51 --> 404 Page Not Found: /index
ERROR - 2020-01-06 16:40:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:40:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:40:08 --> 404 Page Not Found: /index
ERROR - 2020-01-06 16:40:21 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:40:22 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:40:22 --> 404 Page Not Found: /index
ERROR - 2020-01-06 16:40:52 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:40:52 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:40:52 --> 404 Page Not Found: /index
ERROR - 2020-01-06 16:41:02 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:41:03 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:41:03 --> 404 Page Not Found: /index
ERROR - 2020-01-06 16:41:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:41:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:41:08 --> 404 Page Not Found: /index
ERROR - 2020-01-06 16:41:11 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:41:11 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:41:11 --> 404 Page Not Found: /index
ERROR - 2020-01-06 16:41:36 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:41:37 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:41:37 --> 404 Page Not Found: /index
ERROR - 2020-01-06 16:42:18 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:42:18 --> 404 Page Not Found: /index
ERROR - 2020-01-06 16:45:55 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:45:55 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:45:55 --> 404 Page Not Found: /index
ERROR - 2020-01-06 16:46:04 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:46:04 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:46:05 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:46:06 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:46:06 --> 404 Page Not Found: /index
ERROR - 2020-01-06 16:47:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:47:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\danxampp\htdocs\demo\application\modules\function\models\Allfunction.php 88
ERROR - 2020-01-06 16:47:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:47:39 --> 404 Page Not Found: /index
ERROR - 2020-01-06 16:47:49 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:47:49 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:47:49 --> 404 Page Not Found: /index
ERROR - 2020-01-06 16:48:16 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:48:16 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:48:16 --> 404 Page Not Found: /index
ERROR - 2020-01-06 16:54:21 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:54:22 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:54:22 --> 404 Page Not Found: /index
ERROR - 2020-01-06 16:57:06 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:57:07 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 16:57:07 --> 404 Page Not Found: /index
ERROR - 2020-01-06 17:10:11 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 17:10:12 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 17:10:12 --> 404 Page Not Found: /index
ERROR - 2020-01-06 17:10:40 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 17:10:40 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 17:10:40 --> 404 Page Not Found: /index
ERROR - 2020-01-06 17:15:25 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 17:15:26 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 17:15:26 --> 404 Page Not Found: /index
ERROR - 2020-01-06 17:15:49 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 17:15:49 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 17:15:49 --> 404 Page Not Found: /index
ERROR - 2020-01-06 17:15:58 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 17:15:58 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 17:15:58 --> 404 Page Not Found: /index
ERROR - 2020-01-06 17:17:02 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 17:17:03 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 17:17:03 --> 404 Page Not Found: /index
ERROR - 2020-01-06 17:17:23 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 17:17:23 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 17:17:23 --> 404 Page Not Found: /index
ERROR - 2020-01-06 17:17:24 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 17:17:24 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 17:17:24 --> 404 Page Not Found: /index
ERROR - 2020-01-06 17:18:46 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 17:18:46 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 17:18:46 --> 404 Page Not Found: /index
ERROR - 2020-01-06 17:19:25 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 17:19:26 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 17:19:26 --> 404 Page Not Found: /index
ERROR - 2020-01-06 17:30:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 17:30:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 17:30:08 --> 404 Page Not Found: /index
ERROR - 2020-01-06 17:32:00 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 17:32:00 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 17:32:00 --> 404 Page Not Found: /index
ERROR - 2020-01-06 17:32:14 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 17:32:14 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 17:32:14 --> 404 Page Not Found: /index
ERROR - 2020-01-06 17:34:13 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 17:34:13 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 17:34:13 --> 404 Page Not Found: /index
ERROR - 2020-01-06 17:34:20 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 17:34:21 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 17:34:21 --> 404 Page Not Found: /index
ERROR - 2020-01-06 17:34:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 17:34:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 17:34:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 17:34:30 --> 404 Page Not Found: /index
ERROR - 2020-01-06 17:35:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 17:35:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 17:35:42 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 17:35:42 --> 404 Page Not Found: /index
ERROR - 2020-01-06 17:36:52 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 17:36:53 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 17:36:53 --> 404 Page Not Found: /index
ERROR - 2020-01-06 17:37:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 17:37:58 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 17:37:58 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 17:37:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 17:37:59 --> 404 Page Not Found: /index
ERROR - 2020-01-06 17:38:09 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 17:38:09 --> Query error: Duplicate entry '223434' for key 'PRIMARY' - Invalid query: INSERT INTO `import_job_placement` (`beneficiary_id`, `job_placed`, `placement_type`, `sme_or_cpmpany_id`, `wage`, `consortium`, `status`, `postdate`) VALUES ('223434', 'Yes', 'Employment', '10024', '4000', 'Lot1', 1, '2020-01-06')
ERROR - 2020-01-06 17:38:09 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 17:38:09 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 51
ERROR - 2020-01-06 17:38:09 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 17:38:09 --> 404 Page Not Found: /index
ERROR - 2020-01-06 18:08:15 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 18:08:36 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 18:08:37 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 18:08:38 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 18:08:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 18:08:40 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 18:08:40 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 18:08:40 --> 404 Page Not Found: /index
ERROR - 2020-01-06 18:08:50 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 18:08:50 --> Query error: Duplicate entry '223434' for key 'PRIMARY' - Invalid query: INSERT INTO `import_beneficiary_trainings` (`beneficiary_id`, `tvet_id`, `training_module`, `start_date`, `end_date`, `status`, `postdate`) VALUES ('223434', '3445', 'Leather Goods-2-VIS( Entoto PTC )', '2019-03-05', '1970-01-01', 1, '2020-01-06')
ERROR - 2020-01-06 18:08:50 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 18:08:50 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 51
ERROR - 2020-01-06 18:08:50 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 18:08:50 --> 404 Page Not Found: /index
ERROR - 2020-01-06 18:10:20 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 18:10:20 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 18:10:20 --> 404 Page Not Found: /index
ERROR - 2020-01-06 18:57:45 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 18:57:47 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-06 18:57:47 --> 404 Page Not Found: /index
