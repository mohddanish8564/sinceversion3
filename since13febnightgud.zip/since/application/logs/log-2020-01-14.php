<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-14 18:30:36 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-14 18:31:14 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-14 18:31:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-14 19:03:26 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-14 19:03:32 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-14 19:03:32 --> 404 Page Not Found: /index
